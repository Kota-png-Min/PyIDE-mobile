# PyIDE: полный пакет (интерфейс + функционал)

Куда: распакуй в корень проекта (папка, где лежат app, settings.gradle.kts, build.gradle.kts)
и согласись на замену. Пути внутри архива: app/src/main/java/com/pyide/*.kt и app/src/main/python/ide_backend.py.
Архив накопительный: заменяет и предыдущий PyIDE_UI.zip, ставить его отдельно не нужно.
Перед упаковкой проекта для GitHub удали app/build, .gradle, .kotlin, local.properties.

Новое по сравнению с UI-пакетом:
- Terminal: встроенная оболочка (ls, cd, cat, mkdir, touch, rm, mv, cp, echo, python, pip install/uninstall/list, git ...), команда help.
- Подсказки типов серым после переменной (настройки, можно выключить).
- Настройки: размер шрифта, подсказки типов, аргументы запуска.
- Импорт файлов с телефона, экспорт файла и проекта в zip (меню с тремя точками).
- В консоли строки трейсбека кликабельны и открывают файл на нужной строке.

## Плагины
Меню "⋮" -> Главное меню -> Плагины. Плагин это папка с manifest.json и main.py
(лежит во внутренней папке приложения plugins/<id>/), можно создать из шаблона или установить из zip.

manifest.json:
    {
      "id": "my_plugin", "name": "Мой плагин", "version": "1.0", "author": "я",
      "description": "что делает",
      "permissions": ["editor.read", "editor.write"],
      "commands": [{"id": "upper", "title": "ЗАГЛАВНЫЕ", "function": "upper"}]
    }

main.py: функции из commands принимают объект api:
    def upper(api):
        api.set_editor_text(api.editor_text().upper())
        return "готово"

Права: editor.read, editor.write, files.read, files.write, network. Выдаются пользователем.
Безопасный режим выключает плагины полностью. Окружение плагина урезано (нет open/eval/exec,
импорт только безопасных модулей, таймаут 10 с), но это не полная изоляция: ставь только доверенные.

## Шрифт
JetBrains Mono (шрифт PyCharm, SIL OFL 1.1) вшит в assets/fonts вместе с текстом лицензии.
