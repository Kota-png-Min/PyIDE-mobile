"""Система плагинов PyIDE (уровень Sandbox).

Плагин это папка plugins/<id>/ с manifest.json и main.py. Команды плагина запускаются
с объектом api, у которого есть только те функции, на которые пользователь выдал права.
Плагин исполняется в урезанном окружении: нет open/eval/exec, разрешён импорт только
безопасных модулей. Это защита от ошибок и простых злоупотреблений, но НЕ граница
безопасности: ставьте только те плагины, которым доверяете. Safe Mode отключает всё.
"""
import builtins
import ctypes
import io
import json
import os
import re
import shutil
import threading
import types
import urllib.request
import zipfile

BASE = ""
PROJECT = ""
SAFE_MODE = False
TIMEOUT = 10.0

PERMISSIONS = {
    "editor.read": "Читать текст открытого файла",
    "editor.write": "Менять текст открытого файла",
    "files.read": "Читать файлы проекта",
    "files.write": "Создавать и менять файлы проекта",
    "network": "Выходить в интернет",
}
SAFE_MODULES = set((
    "json re math random datetime string itertools collections textwrap difflib time functools "
    "statistics hashlib base64 html unicodedata decimal fractions operator typing dataclasses enum "
    "heapq bisect copy pprint uuid").split())
_ALLOWED_BUILTINS = (
    "abs all any ascii bin bool bytearray bytes callable chr complex dict divmod enumerate filter float "
    "format frozenset hash hex int isinstance issubclass iter len list map max min next oct ord pow range "
    "repr reversed round set slice sorted str sum tuple zip object property staticmethod classmethod super "
    "Exception BaseException ValueError TypeError KeyError IndexError RuntimeError StopIteration "
    "ArithmeticError ZeroDivisionError AttributeError NotImplementedError PermissionError LookupError "
    "UnicodeError ImportError").split()
_ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,31}$")
_FUNC_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,40}$")
_MAX_FILE = 1000000


def init(base, project):
    global BASE, PROJECT
    BASE, PROJECT = os.path.abspath(base), os.path.abspath(project)
    os.makedirs(BASE, exist_ok=True)


def set_safe_mode(flag):
    global SAFE_MODE
    SAFE_MODE = bool(flag)


# ---------------- состояние: права и включённость ----------------

def _state():
    try:
        with open(os.path.join(BASE, "state.json"), encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        d = {}
    d.setdefault("granted", {})
    d.setdefault("enabled", {})
    return d


def _save(d):
    with open(os.path.join(BASE, "state.json"), "w", encoding="utf-8") as f:
        json.dump(d, f)


# ---------------- manifest ----------------

def _manifest(pid):
    info = {"id": pid, "name": pid, "version": "?", "author": "", "description": "",
            "permissions": [], "unknown": [], "commands": [], "error": ""}
    d = os.path.join(BASE, pid)
    try:
        with open(os.path.join(d, "manifest.json"), encoding="utf-8") as f:
            m = json.load(f)
        if not isinstance(m, dict):
            raise ValueError("ожидался объект JSON")
    except Exception as e:
        info["error"] = "manifest.json: %s" % e
        return info
    info["name"] = str(m.get("name", pid))[:60]
    info["version"] = str(m.get("version", "?"))[:20]
    info["author"] = str(m.get("author", ""))[:60]
    info["description"] = str(m.get("description", ""))[:300]
    perms = m.get("permissions", [])
    for p in perms if isinstance(perms, list) else []:
        (info["permissions"] if p in PERMISSIONS else info["unknown"]).append(str(p))
    cmds = m.get("commands", [])
    for c in cmds if isinstance(cmds, list) else []:
        if isinstance(c, dict) and _ID_RE.match(str(c.get("id", ""))) and _FUNC_RE.match(str(c.get("function", ""))):
            info["commands"].append({"id": c["id"], "title": str(c.get("title", c["id"]))[:60], "function": c["function"]})
    if m.get("id") != pid:
        info["error"] = "id в manifest.json не совпадает с именем папки"
    elif not os.path.isfile(os.path.join(d, "main.py")):
        info["error"] = "нет файла main.py"
    return info


def list_plugins():
    if SAFE_MODE or not os.path.isdir(BASE):
        return "[]"
    st = _state()
    out = []
    for pid in sorted(os.listdir(BASE)):
        if not _ID_RE.match(pid) or not os.path.isdir(os.path.join(BASE, pid)):
            continue
        info = _manifest(pid)
        info["granted"] = [p for p in st["granted"].get(pid, []) if p in info["permissions"]]
        info["enabled"] = bool(st["enabled"].get(pid, True))
        out.append(info)
    return json.dumps(out)


def set_permission(pid, perm, on):
    if SAFE_MODE:
        return "Безопасный режим включён"
    if not _ID_RE.match(pid) or perm not in _manifest(pid)["permissions"]:
        return "плагин не запрашивает это право"
    st = _state()
    cur = set(st["granted"].get(pid, []))
    cur.add(perm) if on else cur.discard(perm)
    st["granted"][pid] = sorted(cur)
    _save(st)
    return ""


def set_enabled(pid, on):
    if SAFE_MODE or not _ID_RE.match(pid):
        return "Безопасный режим включён"
    st = _state()
    st["enabled"][pid] = bool(on)
    _save(st)
    return ""


def delete_plugin(pid):
    if SAFE_MODE or not _ID_RE.match(pid):
        return "Безопасный режим включён"
    shutil.rmtree(os.path.join(BASE, pid), ignore_errors=True)
    st = _state()
    st["granted"].pop(pid, None)
    st["enabled"].pop(pid, None)
    _save(st)
    return ""


_TEMPLATE_MAIN = '''# Плагин: {name}
# Функции из manifest.json вызываются с объектом api. Доступно:
#   api.notify(текст)               показать сообщение (всегда)
#   api.editor_text()               текст открытого файла   (право editor.read)
#   api.set_editor_text(текст)      заменить текст файла     (право editor.write)
#   api.read_file(путь)             прочитать файл проекта   (право files.read)
#   api.write_file(путь, текст)     записать файл проекта    (право files.write)
#   api.list_files(папка)           список файлов            (право files.read)
#   api.http_get(url)               скачать текст по адресу  (право network)
# Что вернёт функция, то попадёт в консоль. print тоже попадает в консоль.


def hello(api):
    api.notify("Привет из плагина {name}!")
    return "Готово"


def upper(api):
    text = api.editor_text()
    api.set_editor_text(text.upper())
    return "Символов обработано: %d" % len(text)
'''


def create_plugin(pid, name):
    if SAFE_MODE:
        return "Безопасный режим включён"
    pid = (pid or "").strip()
    name = (name or pid).strip()[:60] or pid
    if not _ID_RE.match(pid):
        return "id: латиница, цифры и _, начинается с буквы, от 2 до 32 символов"
    d = os.path.join(BASE, pid)
    if os.path.exists(d):
        return "плагин с таким id уже есть"
    os.makedirs(d)
    manifest = {
        "id": pid, "name": name, "version": "1.0", "author": "", "description": "Мой плагин",
        "permissions": ["editor.read", "editor.write"],
        "commands": [
            {"id": "hello", "title": "Привет", "function": "hello"},
            {"id": "upper", "title": "ЗАГЛАВНЫЕ БУКВЫ", "function": "upper"},
        ],
    }
    with open(os.path.join(d, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    with open(os.path.join(d, "main.py"), "w", encoding="utf-8") as f:
        f.write(_TEMPLATE_MAIN.replace("{name}", name))
    return ""


def install_zip(path):
    """Установка из zip. Возвращает JSON {ok, id, error}. Папки вне плагина и '..' в архиве запрещены."""
    def fail(msg):
        return json.dumps({"ok": False, "id": "", "error": msg})
    if SAFE_MODE:
        return fail("Безопасный режим включён")
    try:
        with zipfile.ZipFile(path) as z:
            infos = [i for i in z.infolist() if not i.is_dir()]
            if len(infos) > 200 or sum(i.file_size for i in infos) > 5000000:
                return fail("архив слишком большой")
            for i in infos:
                n = i.filename.replace("\\", "/")
                if n.startswith("/") or ".." in n.split("/"):
                    return fail("в архиве недопустимый путь: " + i.filename)
            names = [i.filename.replace("\\", "/") for i in infos]
            mans = [n for n in names if n == "manifest.json" or re.match(r"^[^/]+/manifest\.json$", n)]
            if len(mans) != 1:
                return fail("в архиве должен быть один manifest.json в корне или в одной папке")
            prefix = mans[0][: -len("manifest.json")]
            m = json.loads(z.read(mans[0]).decode("utf-8"))
            pid = str(m.get("id", ""))
            if not _ID_RE.match(pid):
                return fail("недопустимый id плагина в manifest.json")
            target = os.path.join(BASE, pid)
            if os.path.exists(target):
                shutil.rmtree(target)
            for i in infos:
                n = i.filename.replace("\\", "/")
                if not n.startswith(prefix):
                    continue
                dest = os.path.normpath(os.path.join(target, n[len(prefix):]))
                if not dest.startswith(target + os.sep):
                    continue
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with z.open(i) as src, open(dest, "wb") as out:
                    out.write(src.read())
            st = _state()
            st["granted"][pid] = []          # права после установки или обновления выдаются заново
            _save(st)
            return json.dumps({"ok": True, "id": pid, "error": ""})
    except Exception as e:
        return fail("%s: %s" % (type(e).__name__, e))


# ---------------- запуск команд ----------------

def _in_project(p):
    full = os.path.normpath(os.path.join(PROJECT, str(p)))
    if full != PROJECT and not full.startswith(PROJECT + os.sep):
        raise PermissionError("путь вне проекта: %s" % p)
    return full


def _make_api(granted, text, path, result):
    def deny(perm):
        def _f(*a, **k):
            raise PermissionError("плагину не выдано право '%s' (%s)" % (perm, PERMISSIONS[perm]))
        return _f

    impl = {}

    def gate(perm, name, fn):
        impl[name] = fn if perm in granted else deny(perm)

    impl["notify"] = lambda msg: result["notify"].append(str(msg)[:500])

    gate("editor.read", "editor_text", lambda: text)
    gate("editor.read", "editor_path",
         lambda: os.path.relpath(path, PROJECT) if path.startswith(PROJECT) else os.path.basename(path))

    def set_editor_text(t):
        result["set_text"] = str(t)
    gate("editor.write", "set_editor_text", set_editor_text)

    def read_file(p):
        full = _in_project(p)
        if os.path.getsize(full) > _MAX_FILE:
            raise ValueError("файл больше 1 МБ")
        with open(full, encoding="utf-8", errors="replace") as f:
            return f.read()

    def write_file(p, t):
        t = str(t)
        if len(t) > _MAX_FILE:
            raise ValueError("текст больше 1 МБ")
        full = _in_project(p)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(t)

    def list_files(p="."):
        return sorted(os.listdir(_in_project(p)))

    gate("files.read", "read_file", read_file)
    gate("files.read", "list_files", list_files)
    gate("files.write", "write_file", write_file)

    def http_get(url, timeout=15):
        url = str(url)
        if not url.startswith(("http://", "https://")):
            raise ValueError("разрешены только http и https")
        ctx = None
        try:
            import ssl
            import certifi
            ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            pass
        with urllib.request.urlopen(url, timeout=min(float(timeout), 30), context=ctx) as r:
            return r.read(_MAX_FILE).decode("utf-8", "replace")
    gate("network", "http_get", http_get)
    return types.SimpleNamespace(**impl)


def _make_import():
    real = builtins.__import__

    def _imp(name, globals=None, locals=None, fromlist=(), level=0):
        if level != 0 or name.split(".")[0] not in SAFE_MODULES:
            raise ImportError("модуль '%s' запрещён в плагинах" % name)
        return real(name, globals, locals, fromlist, level)
    return _imp


def _safe_builtins(out):
    b = {n: getattr(builtins, n) for n in _ALLOWED_BUILTINS if hasattr(builtins, n)}
    b["__build_class__"] = builtins.__build_class__
    b["__import__"] = _make_import()

    def _print(*a, sep=" ", end="\n", **k):
        out.write(sep.join(str(x) for x in a) + end)
    b["print"] = _print
    return b


def _fmt_error(e, path):
    tb, line = e.__traceback__, None
    while tb is not None:
        if tb.tb_frame.f_code.co_filename == path:
            line = tb.tb_lineno
        tb = tb.tb_next
    msg = "%s: %s" % (type(e).__name__, e)
    return ("строка %d: %s" % (line, msg)) if line else msg


def run_command(pid, cmd_id, editor_text="", editor_path=""):
    def reply(ok, output="", error="", notify=None, set_text=None):
        return json.dumps({"ok": ok, "output": output[:20000], "error": error,
                           "notify": notify or [], "set_text": set_text})
    if SAFE_MODE:
        return reply(False, error="Безопасный режим: плагины отключены")
    if not _ID_RE.match(pid):
        return reply(False, error="недопустимый id плагина")
    info = _manifest(pid)
    st = _state()
    if info["error"]:
        return reply(False, error=info["error"])
    if not st["enabled"].get(pid, True):
        return reply(False, error="плагин выключен")
    cmd = next((c for c in info["commands"] if c["id"] == cmd_id), None)
    if cmd is None:
        return reply(False, error="команда не найдена")
    granted = set(p for p in st["granted"].get(pid, []) if p in info["permissions"])
    path = os.path.join(BASE, pid, "main.py")
    result = {"notify": [], "set_text": None}
    out, err = io.StringIO(), []

    def target():
        try:
            with open(path, encoding="utf-8") as f:
                code = compile(f.read(), path, "exec")
            g = {"__builtins__": _safe_builtins(out), "__name__": "plugin_" + pid}
            exec(code, g)
            fn = g.get(cmd["function"])
            if not callable(fn):
                raise RuntimeError("функция %s не найдена в main.py" % cmd["function"])
            ret = fn(_make_api(granted, editor_text, editor_path, result))
            if ret is not None:
                out.write(str(ret) + "\n")
        except BaseException as e:
            err.append(_fmt_error(e, path))

    th = threading.Thread(target=target, daemon=True)
    th.start()
    th.join(TIMEOUT)
    if th.is_alive():
        if th.ident:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(th.ident), ctypes.py_object(KeyboardInterrupt))
        th.join(2.0)
        return reply(False, out.getvalue(), "превышено время выполнения (%d с)" % int(TIMEOUT), result["notify"])
    if err:
        return reply(False, out.getvalue(), err[0], result["notify"])
    return reply(True, out.getvalue(), "", result["notify"], result["set_text"])
