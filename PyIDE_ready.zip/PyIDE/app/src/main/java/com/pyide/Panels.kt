package com.pyide

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private val TAB_NAMES = listOf("Console", "Terminal", "Debugger", "Problems")

/**
 * Панель Console / Terminal / Debugger / Problems. Стоит сверху (по умолчанию) или снизу.
 * Три положения: свёрнута (только вкладки), открыта, развёрнута. Меняется стрелкой или свайпом по ручке.
 */
@Composable
fun BottomPanel(ide: Ide, big: Boolean, onBig: (Boolean) -> Unit, atTop: Boolean = false) {
    val screenH = LocalConfiguration.current.screenHeightDp
    val bigH: Dp = (screenH * 0.5f).dp
    val target: Dp = when {
        !ide.panelOpen -> 0.dp
        big -> bigH
        else -> 200.dp
    }
    val bodyH by animateDpAsState(target, label = "panelHeight")
    var drag by remember { mutableFloatStateOf(0f) }
    val shape = if (atTop) RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
    else RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    val problems = ide.tabs.getOrNull(ide.active)?.let { ide.problems[it.path]?.size } ?: 0

    // ручка: к центру экрана раскрывает, к краю сворачивает
    val handle: @Composable () -> Unit = {
        Box(
            Modifier
                .fillMaxWidth()
                .height(26.dp)
                .pointerInput(big, atTop) {
                    detectVerticalDragGestures(
                        onDragStart = { drag = 0f },
                        onDragCancel = { drag = 0f },
                        onDragEnd = {
                            val expand = if (atTop) drag > 30f else drag < -30f
                            val collapse = if (atTop) drag < -30f else drag > 30f
                            if (expand) {
                                if (!ide.panelOpen) ide.panelOpen = true else onBig(true)
                            } else if (collapse) {
                                if (big) onBig(false) else ide.panelOpen = false
                            }
                            drag = 0f
                        },
                        onVerticalDrag = { _, dy -> drag += dy }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .width(44.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Ds.gray)
            )
        }
    }

    val chevron = if (atTop) {
        if (ide.panelOpen) Ic.ChevronUp else Ic.ChevronDown
    } else {
        if (ide.panelOpen) Ic.ChevronDown else Ic.ChevronUp
    }

    val header: @Composable () -> Unit = {
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(
                    start = 12.dp, end = 12.dp,
                    top = if (atTop) 8.dp else 0.dp,
                    bottom = if (atTop) 4.dp else 10.dp
                ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TAB_NAMES.forEachIndexed { i, name ->
                val label = when {
                    i == 3 && problems > 0 -> "$name ($problems)"
                    i == 2 && ide.runState.pause != null -> "$name (paused)"
                    else -> name
                }
                DsChip(label, selected = ide.panelTab == i, onClick = {
                    if (ide.panelTab == i) ide.panelOpen = !ide.panelOpen
                    else { ide.panelTab = i; ide.panelOpen = true }
                })
            }
            DsIconButton(
                chevron,
                onClick = {
                    ide.panelOpen = !ide.panelOpen
                    if (!ide.panelOpen) onBig(false)
                },
                size = 40.dp
            )
        }
    }

    val body: @Composable () -> Unit = {
        if (bodyH > 0.dp) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(bodyH)
            ) {
                when (ide.panelTab) {
                    0 -> ConsolePanel(ide)
                    1 -> TerminalPanel(ide)
                    2 -> DebuggerPanel(ide)
                    else -> ProblemsPanel(ide)
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Ds.surface)
    ) {
        if (atTop) {
            header()
            body()
            handle()
        } else {
            handle()
            header()
            body()
        }
    }
}

@Composable
private fun LogBox(text: String, modifier: Modifier = Modifier) {
    val scroll = rememberScrollState()
    LaunchedEffect(text.length) {
        delay(30)
        scroll.scrollTo(scroll.maxValue)
    }
    Box(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Ds.field)
    ) {
        Text(
            text, style = Ds.mono,
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scroll)
                .padding(12.dp)
        )
    }
}

// ======================= Console =======================

private val TRACE_RE = Regex("""File "(.+?)", line (\d+)""")

/** Вывод программы построчно. Строки трейсбека с файлом проекта кликабельны. */
@Composable
private fun LogLines(text: String, ide: Ide, modifier: Modifier = Modifier) {
    val lines = remember(text) { text.split("\n").takeLast(1500) }
    val state = rememberLazyListState()
    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) state.scrollToItem(lines.size - 1)
    }
    Box(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Ds.field)
    ) {
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            state = state
        ) {
            itemsIndexed(lines) { _, line ->
                val m = TRACE_RE.find(line)
                val target = if (m != null) File(m.groupValues[1]).takeIf { it.exists() && it.path.startsWith(ide.root.path) } else null
                if (m != null && target != null) {
                    Text(
                        line, style = Ds.mono, color = Ds.orange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { ide.gotoLine(target.path, m.groupValues[2].toInt()) }
                            .padding(vertical = 4.dp)
                    )
                } else {
                    Text(line, style = Ds.mono)
                }
            }
        }
    }
}

@Composable
fun ConsolePanel(ide: Ide) {
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    fun send() {
        if (!ide.runState.running) return
        val line = input
        input = ""
        scope.launch { ide.sendInput(line) }
    }
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
            .padding(bottom = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DsButton(
                "Stop", onClick = { scope.launch { ide.stop() } },
                kind = DsBtn.Outlined, enabled = ide.runState.running, icon = Ic.Stop
            )
            DsButton("Clear", onClick = { ide.console = "" }, kind = DsBtn.Gray)
            if (ide.runState.waitingInput) {
                Text("ждёт ввод", style = Ds.caption, color = Ds.orange)
            }
        }
        LogLines(ide.console, ide, Modifier.weight(1f).fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DsField(
                input, { input = it }, "Ввод для input()", Modifier.weight(1f),
                onSend = { send() }, onFocus = { ide.panelFocused = it }
            )
            DsIconButton(Ic.Send, onClick = { send() }, enabled = ide.runState.running, filled = true)
        }
    }
}

// ======================= Terminal =======================

@Composable
fun TerminalPanel(ide: Ide) {
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    fun send() {
        val line = input
        input = ""
        scope.launch { ide.termSend(line) }
    }
    val prompt = if (ide.termRepl) (if (ide.termMore) "..." else ">>>") else "$"
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
            .padding(bottom = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DsButton("Clear", onClick = { ide.termText = "" }, kind = DsBtn.Gray)
            DsButton("help", onClick = { scope.launch { ide.termSend("help") } }, kind = DsBtn.Outlined)
            if (ide.termRepl) {
                DsButton("exit()", onClick = { scope.launch { ide.termSend("exit()") } }, kind = DsBtn.Outlined)
            }
            Text(if (ide.termRepl) "Python" else ide.termCwd, style = Ds.caption)
        }
        LogBox(ide.termText, Modifier.weight(1f).fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DsIconButton(Ic.ChevronUp, onClick = { input = ide.termPrev() }, size = 44.dp)
            Text(prompt, style = Ds.mono, color = Ds.orange)
            DsField(
                input, { input = it }, "pip install requests", Modifier.weight(1f),
                onSend = { send() }, onFocus = { ide.panelFocused = it }
            )
            DsIconButton(Ic.Send, onClick = { send() }, filled = true)
        }
    }
}

// ======================= Debugger =======================

@Composable
fun DebuggerPanel(ide: Ide) {
    val scope = rememberCoroutineScope()
    var expr by remember { mutableStateOf("") }
    val p = ide.runState.pause
    if (p == null) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
            Text(
                if (ide.runState.running) "Программа выполняется…"
                else "Тапни по номеру строки в редакторе, чтобы поставить красную точку, затем нажми кнопку Debug вверху.",
                style = Ds.subhead, color = Ds.gray
            )
        }
        return
    }
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
            .padding(bottom = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DsButton("Resume", onClick = { scope.launch { ide.dbg("c") } }, icon = Ic.Resume)
            DsButton("Step Over", onClick = { scope.launch { ide.dbg("n") } }, kind = DsBtn.Gray, icon = Ic.StepOver)
            DsButton("Step Into", onClick = { scope.launch { ide.dbg("s") } }, kind = DsBtn.Gray, icon = Ic.StepInto)
            DsButton("Step Out", onClick = { scope.launch { ide.dbg("r") } }, kind = DsBtn.Gray, icon = Ic.StepOut)
            DsButton("Stop", onClick = { scope.launch { ide.stop() } }, kind = DsBtn.Outlined, icon = Ic.Stop)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DsField(
                expr, { expr = it }, "Выражение (eval)", Modifier.weight(1f),
                onSend = { scope.launch { ide.evalExpr(expr) } }, onFocus = { ide.panelFocused = it }
            )
            DsIconButton(Ic.Send, onClick = { scope.launch { ide.evalExpr(expr) } }, filled = true)
        }
        if (ide.evalResult.isNotEmpty()) {
            Text("Result: ${ide.evalResult}", style = Ds.mono, color = Ds.orange)
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            item { Text("Call stack", style = Ds.headline, modifier = Modifier.padding(vertical = 6.dp)) }
            items(p.stack) { s ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn44()
                        .clickable { ide.gotoLine(s.file, s.line) },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DsIcon(Ic.ChevronRight, Ds.orange, 16.dp)
                    Text("${s.fn}()", style = Ds.mono, color = Color.White)
                    Text("${File(s.file).name}:${s.line}", style = Ds.caption)
                }
            }
            item { Text("Variables", style = Ds.headline, modifier = Modifier.padding(vertical = 6.dp)) }
            items(p.vars) { v ->
                Text(
                    "${v.name} = ${v.repr}",
                    style = Ds.mono,
                    modifier = Modifier.padding(vertical = 3.dp)
                )
            }
        }
    }
}

private fun Modifier.heightIn44(): Modifier = this.then(Modifier.height(44.dp))

// ======================= Problems =======================

@Composable
fun ProblemsPanel(ide: Ide) {
    val f = ide.tabs.getOrNull(ide.active)
    val list = f?.let { ide.problems[it.path] }.orEmpty()
    if (list.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DsIcon(Ic.Check, Ds.green, 20.dp)
                Text("Ошибок не найдено", style = Ds.subhead, color = Ds.gray)
            }
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        items(list) { pr ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { f?.let { ide.gotoLine(it.path, pr.line, pr.col) } }
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DsIcon(Ic.Warning, Ds.red, 18.dp)
                Column {
                    Text(pr.msg, style = Ds.subhead, color = Color.White)
                    Text("строка ${pr.line}, столбец ${pr.col + 1}", style = Ds.caption)
                }
            }
        }
    }
}
