package com.pyide

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Настройки интерфейса. Хранятся в SharedPreferences, читаются при старте. */
object Prefs {
    /** Все символы, которые можно закрепить на панели над клавиатурой. */
    const val ALL_SYMBOLS = "()[]{}\"':;=#.,+-*/%<>!&|@_\\~^?"
    const val DEFAULT_SYMBOLS = "()[]{}\"':=#.,+-*/<>"

    var fontSize by mutableFloatStateOf(14f)
    var hints by mutableStateOf(true)
    var amoled by mutableStateOf(false)
    var haptics by mutableStateOf(true)
    var panelTop by mutableStateOf(true)
    var ghost by mutableStateOf(true)
    var jbFont by mutableStateOf(true)
    var safeMode by mutableStateOf(false)
    var symbols by mutableStateOf(DEFAULT_SYMBOLS)
    private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("pyide", Context.MODE_PRIVATE)
        sp = p
        fontSize = p.getFloat("font", 14f)
        hints = p.getBoolean("hints", true)
        amoled = p.getBoolean("amoled", false)
        haptics = p.getBoolean("haptics", true)
        panelTop = p.getBoolean("panelTop", true)
        ghost = p.getBoolean("ghost", true)
        jbFont = p.getBoolean("jbFont", true)
        safeMode = p.getBoolean("safeMode", false)
        symbols = p.getString("symbols", DEFAULT_SYMBOLS) ?: DEFAULT_SYMBOLS
    }

    fun save() {
        sp?.edit()
            ?.putFloat("font", fontSize)
            ?.putBoolean("hints", hints)
            ?.putBoolean("amoled", amoled)
            ?.putBoolean("haptics", haptics)
            ?.putBoolean("panelTop", panelTop)
            ?.putBoolean("ghost", ghost)
            ?.putBoolean("jbFont", jbFont)
            ?.putBoolean("safeMode", safeMode)
            ?.putString("symbols", symbols)
            ?.apply()
    }
}
