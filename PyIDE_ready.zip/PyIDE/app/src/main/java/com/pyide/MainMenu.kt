package com.pyide

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Действия, которые главное меню передаёт главному экрану. */
enum class MenuAction { Import, ExportFile, ExportZip, Search, Pip, Git, History }

val PERM_LABELS = mapOf(
    "editor.read" to "Читать текст открытого файла",
    "editor.write" to "Менять текст открытого файла",
    "files.read" to "Читать файлы проекта",
    "files.write" to "Создавать и менять файлы проекта",
    "network" to "Выходить в интернет"
)

@Composable
private fun MenuCard(
    ic: Ic, title: String, subtitle: String, onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Ds.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Ds.bg),
            contentAlignment = Alignment.Center
        ) { DsIcon(ic, Ds.orange, 24.dp) }
        Column(Modifier.weight(1f)) {
            Text(title, style = Ds.headline)
            if (subtitle.isNotEmpty()) Text(subtitle, style = Ds.caption)
        }
        if (trailing != null) trailing() else DsIcon(Ic.ChevronRight, Ds.gray, 20.dp)
    }
}

/** Главное меню на весь экран: настройки, плагины, создание плагинов, безопасный режим, проект. */
@Composable
fun MainMenu(ide: Ide, onClose: () -> Unit, onAction: (MenuAction) -> Unit) {
    var page by remember { mutableIntStateOf(0) }   // 0 меню, 1 настройки, 2 плагины, 3 создание плагина
    val titles = listOf("Меню", "Настройки", "Плагины", "Создать плагин")
    LaunchedEffect(Unit) { ide.pluginsRefresh() }

    Dialog(
        onDismissRequest = { if (page != 0) page = 0 else onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Ds.bg)
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (page != 0) DsIconButton(Ic.ChevronLeft, onClick = { page = 0 })
                Text(
                    titles[page], style = Ds.title2,
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = if (page == 0) 8.dp else 0.dp)
                )
                DsIconButton(Ic.Close, onClick = onClose)
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (page) {
                    0 -> HomePage(ide, onPage = { page = it }, act = { onClose(); onAction(it) })
                    1 -> Column(
                        Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) { SettingsContent(ide) }
                    2 -> PluginsPage(ide, onClose, onCreate = { page = 3 })
                    else -> CreatePluginPage(ide, onClose)
                }
            }
        }
    }
}

@Composable
private fun HomePage(ide: Ide, onPage: (Int) -> Unit, act: (MenuAction) -> Unit) {
    val scope = rememberCoroutineScope()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        MenuCard(Ic.Gear, "Настройки", "Шрифт, тема, панели, символы", { onPage(1) })
        MenuCard(
            Ic.Plugin, "Плагины",
            if (Prefs.safeMode) "Отключены безопасным режимом" else "Установлено: ${ide.plugins.size}",
            { onPage(2) }
        )
        MenuCard(Ic.Plus, "Создать плагин", "Шаблон: manifest.json и main.py", { onPage(3) })
        MenuCard(
            Ic.Shield, "Безопасный режим", "Полностью отключает систему плагинов",
            onClick = { scope.launch { ide.setSafeMode(!Prefs.safeMode) } },
            trailing = { DsSwitch(Prefs.safeMode) { on -> scope.launch { ide.setSafeMode(on) } } }
        )
        Text("Проект", style = Ds.caption, modifier = Modifier.padding(start = 4.dp, top = 8.dp))
        MenuCard(Ic.Terminal, "Пакеты (pip)", "Установка библиотек", { act(MenuAction.Pip) })
        MenuCard(Ic.Branch, "Git", "Коммиты, push и pull", { act(MenuAction.Git) })
        MenuCard(Ic.Refresh, "История файла", "Версии и откат", { act(MenuAction.History) })
        MenuCard(Ic.Search, "Поиск по проекту", "", { act(MenuAction.Search) })
        MenuCard(Ic.Plus, "Импорт файлов", "С телефона в проект", { act(MenuAction.Import) })
        MenuCard(Ic.Send, "Экспорт файла", "Сохранить открытый файл", { act(MenuAction.ExportFile) })
        MenuCard(Ic.Folder, "Экспорт проекта (zip)", "Весь проект одним архивом", { act(MenuAction.ExportZip) })
    }
}

// ======================= Плагины =======================

private suspend fun installPluginZip(ctx: Context, uri: Uri): String = withContext(Dispatchers.IO) {
    try {
        val tmp = File(ctx.cacheDir, "plugin_in.zip")
        val opened = ctx.contentResolver.openInputStream(uri)
            ?: return@withContext "Не удалось открыть файл"
        opened.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        val (ok, info) = Backend.pluginInstall(tmp.absolutePath)
        tmp.delete()
        if (ok) "Установлен плагин: $info. Выдай ему права ниже." else "Ошибка установки: $info"
    } catch (e: Exception) {
        "Ошибка: ${e.message}"
    }
}

@Composable
private fun PluginsPage(ide: Ide, onClose: () -> Unit, onCreate: () -> Unit) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Pair<PluginInfo, PluginCmd>?>(null) }
    var deleting by remember { mutableStateOf<PluginInfo?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                msg = installPluginZip(ctx, uri)
                ide.pluginsRefresh()
            }
        }
    }
    LaunchedEffect(Unit) { ide.pluginsRefresh() }

    fun requestRun(p: PluginInfo, c: PluginCmd) {
        val missing = p.permissions.filter { it !in p.granted }
        if (missing.isEmpty()) {
            scope.launch {
                ide.pluginRun(p, c)
                onClose()
            }
        } else {
            pending = p to c
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (Prefs.safeMode) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .outlinedCard(20.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DsIcon(Ic.Shield, Ds.orange, 22.dp)
                    Text("Безопасный режим включён", style = Ds.headline)
                }
                Text(
                    "Плагины не загружаются и не запускаются. Права, установка и создание недоступны.",
                    style = Ds.subhead, color = Ds.gray
                )
                DsButton("Выключить безопасный режим", onClick = { scope.launch { ide.setSafeMode(false) } })
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DsButton(
                    "Установить из zip", icon = Ic.Plus,
                    onClick = { picker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
                )
                DsButton("Создать", onClick = onCreate, kind = DsBtn.Gray)
            }
            Text(
                "Плагины работают в урезанном окружении и получают только выданные тобой права. " +
                    "Это не полная изоляция: ставь только плагины, которым доверяешь.",
                style = Ds.caption
            )
            if (msg.isNotEmpty()) Text(msg, style = Ds.subhead, color = Ds.orange)
            if (ide.plugins.isEmpty()) {
                Text("Плагинов пока нет. Установи из zip или создай свой.", style = Ds.subhead, color = Ds.gray)
            }
            ide.plugins.forEach { p ->
                PluginCard(
                    ide, p,
                    onRun = { pl, c -> requestRun(pl, c) },
                    onDelete = { deleting = it },
                    onEdit = { pl ->
                        ide.open(File(ide.pluginsDir, pl.id + "/main.py"))
                        onClose()
                    }
                )
            }
        }
    }

    pending?.let { (pl, c) ->
        val missing = pl.permissions.filter { it !in pl.granted }
        AlertDialog(
            onDismissRequest = { pending = null },
            containerColor = Ds.surface,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Плагину нужны права", style = Ds.title2) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Плагин «${pl.name}» просит:", style = Ds.subhead, color = Ds.gray)
                    missing.forEach { Text("- " + (PERM_LABELS[it] ?: it), style = Ds.body) }
                }
            },
            confirmButton = {
                DsButton("Разрешить и запустить", onClick = {
                    pending = null
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            missing.forEach { perm -> Backend.pluginPerm(pl.id, perm, true) }
                        }
                        ide.pluginsRefresh()
                        ide.pluginRun(pl, c)
                        onClose()
                    }
                })
            },
            dismissButton = {
                DsButton("Без них", kind = DsBtn.Gray, onClick = {
                    pending = null
                    scope.launch {
                        ide.pluginRun(pl, c)
                        onClose()
                    }
                })
            }
        )
    }

    deleting?.let { p ->
        ConfirmDialog(
            title = "Удалить плагин",
            text = "Плагин ${p.name} будет удалён вместе с файлами.",
            onDismiss = { deleting = null },
            onYes = {
                deleting = null
                scope.launch {
                    withContext(Dispatchers.IO) { Backend.pluginDelete(p.id) }
                    ide.pluginsRefresh()
                }
            }
        )
    }
}

@Composable
private fun PluginCard(
    ide: Ide, p: PluginInfo,
    onRun: (PluginInfo, PluginCmd) -> Unit,
    onDelete: (PluginInfo) -> Unit,
    onEdit: (PluginInfo) -> Unit,
) {
    val scope = rememberCoroutineScope()
    Column(
        Modifier
            .fillMaxWidth()
            .outlinedCard(20.dp)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.name, style = Ds.headline)
                Text(
                    "v${p.version}" + (if (p.author.isNotEmpty()) " / ${p.author}" else "") + "  id: ${p.id}",
                    style = Ds.caption
                )
            }
            DsSwitch(p.enabled) { on ->
                scope.launch {
                    withContext(Dispatchers.IO) { Backend.pluginEnable(p.id, on) }
                    ide.pluginsRefresh()
                }
            }
        }
        if (p.description.isNotEmpty()) Text(p.description, style = Ds.subhead, color = Ds.gray)
        if (p.error.isNotEmpty()) Text("Ошибка: ${p.error}", style = Ds.subhead, color = Ds.red)
        if (p.permissions.isNotEmpty() || p.unknown.isNotEmpty()) Text("Права", style = Ds.headline)
        p.permissions.forEach { perm ->
            SwitchRow(PERM_LABELS[perm] ?: perm, perm, perm in p.granted) { on ->
                scope.launch {
                    withContext(Dispatchers.IO) { Backend.pluginPerm(p.id, perm, on) }
                    ide.pluginsRefresh()
                }
            }
        }
        p.unknown.forEach {
            Text("Неизвестное право: $it (не будет выдано)", style = Ds.caption, color = Ds.red)
        }
        if (p.commands.isNotEmpty()) Text("Команды", style = Ds.headline)
        p.commands.forEach { c ->
            DsButton(
                c.title, icon = Ic.Play, modifier = Modifier.fillMaxWidth(),
                enabled = p.enabled && p.error.isEmpty(),
                onClick = { onRun(p, c) }
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DsButton("Править код", onClick = { onEdit(p) }, kind = DsBtn.Gray, icon = Ic.Pencil)
            DsButton("Удалить", onClick = { onDelete(p) }, kind = DsBtn.Outlined, icon = Ic.Trash)
        }
    }
}

@Composable
private fun CreatePluginPage(ide: Ide, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var id by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (Prefs.safeMode) {
            Text(
                "В безопасном режиме плагины создавать нельзя. Выключи его в главном меню.",
                style = Ds.subhead, color = Ds.gray
            )
        } else {
            Text(
                "Плагин это папка с manifest.json (описание и права) и main.py (код). " +
                    "Шаблон уже содержит две рабочие команды.",
                style = Ds.subhead, color = Ds.gray
            )
            Text("id (латиница, цифры, _)", style = Ds.headline)
            DsField(id, { id = it.lowercase() }, "my_plugin", Modifier.fillMaxWidth())
            Text("Название", style = Ds.headline)
            DsField(name, { name = it }, "Мой плагин", Modifier.fillMaxWidth(), mono = false)
            if (err.isNotEmpty()) Text(err, style = Ds.subhead, color = Ds.red)
            DsButton(
                "Создать и открыть код", icon = Ic.Plus, modifier = Modifier.fillMaxWidth(),
                enabled = id.isNotBlank(),
                onClick = {
                    scope.launch {
                        err = ide.pluginCreate(id, name)
                        if (err.isEmpty()) onClose()
                    }
                }
            )
        }
    }
}
