package com.pyide

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val DialogShape = RoundedCornerShape(28.dp)

// ======================= Имя файла =======================

@Composable
fun NameDialog(title: String, initial: String, hint: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ds.surface,
        shape = DialogShape,
        title = { Text(title, style = Ds.title2) },
        text = { DsField(name, { name = it }, hint, Modifier.fillMaxWidth(), onSend = { onOk(name) }) },
        confirmButton = { DsButton("OK", onClick = { onOk(name) }, enabled = name.isNotBlank()) },
        dismissButton = { DsButton("Отмена", onClick = onDismiss, kind = DsBtn.Gray) }
    )
}

// ======================= Подтверждение =======================

@Composable
fun ConfirmDialog(title: String, text: String, onDismiss: () -> Unit, onYes: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ds.surface,
        shape = DialogShape,
        title = { Text(title, style = Ds.title2) },
        text = { Text(text, style = Ds.body) },
        confirmButton = { DsButton("Удалить", onClick = onYes) },
        dismissButton = { DsButton("Отмена", onClick = onDismiss, kind = DsBtn.Gray) }
    )
}

// ======================= Пакеты (pip) =======================

@Composable
fun PipDialog(onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ds.surface,
        shape = DialogShape,
        title = { Text("Пакеты (pip)", style = Ds.title2) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Чисто-Python пакеты ставятся с PyPI, пакеты с C-кодом берутся готовыми " +
                        "Android-сборками из репозитория Chaquopy. Встроены: numpy, requests, " +
                        "jedi, pyflakes, autopep8, dulwich.",
                    style = Ds.caption
                )
                DsField(name, { name = it }, "например: rich  или  pandas", Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DsButton("Pandas", onClick = { name = "pandas" }, kind = DsBtn.Gray)
                    DsButton("Pillow", onClick = { name = "pillow" }, kind = DsBtn.Gray)
                    DsButton("SciPy", onClick = { name = "scipy" }, kind = DsBtn.Gray)
                }
                DsButton(
                    if (busy) "Подожди…" else "Установить",
                    enabled = !busy && name.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        scope.launch {
                            busy = true
                            log = "Установка…"
                            log = withContext(Dispatchers.IO) { Backend.pip(name) }
                            busy = false
                        }
                    }
                )
                Text(
                    log, style = Ds.mono,
                    modifier = Modifier
                        .heightIn(max = 200.dp)
                        .verticalScroll(rememberScrollState())
                )
            }
        },
        confirmButton = { DsButton("Закрыть", onClick = onDismiss, kind = DsBtn.Gray) }
    )
}

// ======================= Поиск по проекту =======================

@Composable
fun SearchDialog(ide: Ide, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf(listOf<Hit>()) }
    var searched by remember { mutableStateOf(false) }
    fun go() {
        scope.launch {
            hits = ide.searchProject(q)
            searched = true
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ds.surface,
        shape = DialogShape,
        title = { Text("Поиск по проекту", style = Ds.title2) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DsField(q, { q = it }, "Что искать", Modifier.weight(1f), onSend = { go() })
                    DsIconButton(Ic.Search, onClick = { go() }, filled = true)
                }
                if (searched && hits.isEmpty()) Text("Ничего не найдено", style = Ds.subhead, color = Ds.gray)
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(hits) { h ->
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { ide.gotoLine(h.file.path, h.line); onDismiss() }
                                .padding(horizontal = 8.dp, vertical = 8.dp)
                        ) {
                            Text(
                                "${h.file.relativeTo(ide.root).path}:${h.line}",
                                style = Ds.caption, color = Ds.orange
                            )
                            Text(h.text, style = Ds.mono, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        },
        confirmButton = { DsButton("Закрыть", onClick = onDismiss, kind = DsBtn.Gray) }
    )
}

// ======================= Git =======================

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun GitDialog(ide: Ide, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var dir by remember { mutableStateOf(".") }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun run(cmd: String, a: String = "", b: String = "", c: String = "") {
        scope.launch {
            busy = true
            out = "…"
            out = withContext(Dispatchers.IO) {
                try { Backend.git(cmd, dir, a, b, c) } catch (e: Exception) { "Ошибка: $e" }
            }
            ide.refresh()
            busy = false
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ds.surface,
        shape = DialogShape,
        modifier = Modifier.fillMaxWidth(0.97f),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text("Git", style = Ds.title2) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DsField(dir, { dir = it }, "Папка репозитория (. = корень)", Modifier.fillMaxWidth())
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DsButton("Init", onClick = { run("init") }, kind = DsBtn.Gray, enabled = !busy)
                    DsButton("Status", onClick = { run("status") }, kind = DsBtn.Gray, enabled = !busy)
                    DsButton("Diff", onClick = { run("diff") }, kind = DsBtn.Gray, enabled = !busy)
                    DsButton("Log", onClick = { run("log") }, kind = DsBtn.Gray, enabled = !busy)
                }
                Text("Коммит", style = Ds.headline)
                DsField(name, { name = it }, "Имя автора", Modifier.fillMaxWidth(), mono = false)
                DsField(email, { email = it }, "Email автора", Modifier.fillMaxWidth())
                DsField(msg, { msg = it }, "Сообщение коммита", Modifier.fillMaxWidth(), mono = false)
                DsButton(
                    "Добавить всё и закоммитить", onClick = { run("commit", msg, name, email) },
                    enabled = !busy, modifier = Modifier.fillMaxWidth()
                )
                Text("Удалённый репозиторий", style = Ds.headline)
                Text("Токен хранится только в памяти и на диск не пишется.", style = Ds.caption)
                DsField(url, { url = it }, "https://github.com/user/repo.git", Modifier.fillMaxWidth())
                DsField(user, { user = it }, "Логин", Modifier.fillMaxWidth())
                DsField(token, { token = it }, "Токен (PAT)", Modifier.fillMaxWidth(), password = true)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DsButton("Clone", enabled = !busy && url.isNotBlank(), onClick = {
                        val nm = url.trimEnd('/').substringAfterLast('/').removeSuffix(".git")
                        dir = nm
                        run("clone", url, user, token)
                    })
                    DsButton("Remote", kind = DsBtn.Gray, enabled = !busy && url.isNotBlank(), onClick = { run("remote", url) })
                    DsButton("Push", kind = DsBtn.Outlined, enabled = !busy, onClick = { run("push", user, token) })
                    DsButton("Pull", kind = DsBtn.Outlined, enabled = !busy, onClick = { run("pull", user, token) })
                }
                Text(
                    out, style = Ds.mono,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Ds.field)
                        .padding(12.dp)
                )
            }
        },
        confirmButton = { DsButton("Закрыть", onClick = onDismiss, kind = DsBtn.Gray) }
    )
}

// ======================= Настройки =======================

@Composable
fun DsSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = Ds.orange,
            checkedBorderColor = Ds.orange,
            uncheckedThumbColor = Ds.gray,
            uncheckedTrackColor = Ds.field,
            uncheckedBorderColor = Ds.line
        )
    )
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Ds.headline)
            Text(subtitle, style = Ds.caption)
        }
        DsSwitch(checked, onChange)
    }
}

/** Содержимое настроек. Используется и в главном меню, и в диалоге. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsContent(ide: Ide) {
    var args by remember { mutableStateOf(ide.runArgs) }
    DisposableEffect(Unit) { onDispose { Prefs.save() } }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Размер шрифта: ${Prefs.fontSize.toInt()}", style = Ds.headline)
        Slider(
            value = Prefs.fontSize,
            onValueChange = { Prefs.fontSize = it.roundToInt().toFloat() },
            valueRange = 10f..24f,
            steps = 13,
            colors = SliderDefaults.colors(
                thumbColor = Ds.orange,
                activeTrackColor = Ds.orange,
                inactiveTrackColor = Ds.line,
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent
            )
        )
        SwitchRow("Шрифт JetBrains Mono", "Как в PyCharm. Выключи, чтобы взять системный", Prefs.jbFont) { Prefs.jbFont = it }
        SwitchRow("Терминал сверху", "Панель с консолью и терминалом над редактором", Prefs.panelTop) { Prefs.panelTop = it }
        SwitchRow("AMOLED-тема", "Чистый чёрный фон", Prefs.amoled) { Prefs.amoled = it }
        SwitchRow("Тактильный отклик", "Лёгкая вибрация при действиях", Prefs.haptics) { Prefs.haptics = it }
        SwitchRow("Призрачный текст", "Серое окончание слова в строке, Tab его принимает", Prefs.ghost) { Prefs.ghost = it }
        SwitchRow("Подсказки типов", "Серым после переменной: x : int", Prefs.hints) { Prefs.hints = it }
        Text("Панель символов", style = Ds.headline)
        Text("Нажми на символ, чтобы закрепить или убрать его с панели над клавиатурой.", style = Ds.caption)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Prefs.ALL_SYMBOLS.forEach { ch ->
                val on = Prefs.symbols.contains(ch)
                DsChip(ch.toString(), selected = on, onClick = {
                    Prefs.symbols = Prefs.ALL_SYMBOLS.filter { c -> if (c == ch) !on else Prefs.symbols.contains(c) }
                })
            }
        }
        DsButton("Сбросить символы", onClick = { Prefs.symbols = Prefs.DEFAULT_SYMBOLS }, kind = DsBtn.Gray)
        Text("Аргументы запуска", style = Ds.headline)
        DsField(args, { args = it; ide.runArgs = it }, "например: --debug 5", Modifier.fillMaxWidth())
        Text("Передаются программе как sys.argv.", style = Ds.caption)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDialog(ide: Ide, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ds.surface,
        shape = DialogShape,
        title = { Text("Настройки", style = Ds.title2) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState())
            ) { SettingsContent(ide) }
        },
        confirmButton = { DsButton("Готово", onClick = onDismiss) }
    )
}

// ======================= История версий =======================

private fun reasonLabel(r: String): String = when (r) {
    "run" -> "Перед запуском"
    "manual" -> "Сохранено вручную"
    "format" -> "Перед форматированием"
    "replace" -> "Перед заменой"
    "auto" -> "Автосохранение"
    "restore" -> "Перед откатом"
    "plugin" -> "Перед плагином"
    else -> r
}

@Composable
fun VersionsDialog(ide: Ide, f: File, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val snaps = remember(f) { History.list(ide.root, f) }
    var selected by remember { mutableStateOf<Snap?>(null) }
    var diff by remember { mutableStateOf("") }
    val fmt = remember { SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()) }
    val current = ide.texts[f.path]?.text ?: ""

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ds.surface,
        shape = DialogShape,
        modifier = Modifier.fillMaxWidth(0.97f),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text(if (selected == null) "История: ${f.name}" else "Изменения", style = Ds.title2) },
        text = {
            val sel = selected
            if (sel == null) {
                if (snaps.isEmpty()) {
                    Text(
                        "Версий пока нет. Они создаются перед запуском, форматированием, заменой и каждые 5 минут.",
                        style = Ds.subhead, color = Ds.gray
                    )
                } else {
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(snaps) { sn ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable {
                                        selected = sn
                                        scope.launch {
                                            diff = withContext(Dispatchers.IO) {
                                                try { Backend.diff(History.read(sn), current) } catch (e: Exception) { "Ошибка: $e" }
                                            }
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(fmt.format(Date(sn.time)), style = Ds.mono, color = Ds.orange)
                                Text(reasonLabel(sn.reason), style = Ds.body)
                            }
                        }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Красным: было в версии от ${fmt.format(Date(sel.time))}. Зелёным: сейчас в файле.",
                        style = Ds.caption
                    )
                    if (diff.isBlank()) {
                        Text("Эта версия совпадает с текущим текстом.", style = Ds.subhead, color = Ds.gray)
                    }
                    val lines = remember(diff) { diff.split("\n") }
                    LazyColumn(
                        Modifier
                            .heightIn(max = 380.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Ds.field)
                            .padding(8.dp)
                    ) {
                        items(lines) { l ->
                            val color = when {
                                l.startsWith("+") && !l.startsWith("+++") -> Ds.green
                                l.startsWith("-") && !l.startsWith("---") -> Ds.red
                                l.startsWith("@@") -> Ds.orange
                                else -> Color(0xFFD0D0D4)
                            }
                            Text(l, style = Ds.mono, color = color)
                        }
                    }
                }
            }
        },
        confirmButton = {
            val sel = selected
            if (sel == null) {
                DsButton("Закрыть", onClick = onDismiss, kind = DsBtn.Gray)
            } else {
                DsButton("Восстановить", onClick = { ide.restore(f, sel); onDismiss() })
            }
        },
        dismissButton = {
            if (selected != null) DsButton("Назад", onClick = { selected = null }, kind = DsBtn.Gray)
        }
    )
}
