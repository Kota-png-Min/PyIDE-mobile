package com.pyide

import java.io.File
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

data class Snap(val time: Long, val reason: String, val file: File)

/**
 * Local History: снимки текста файла, сжатые gzip (хранится только то, что изменилось
 * с прошлого снимка). Лежат рядом с проектом, в папке history.
 */
object History {
    private const val MAX = 40
    private val NAME = Regex("""(\d+)_(\w+)\.gz""")

    private fun dirFor(root: File, f: File): File {
        val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
        val safe = rel.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dir = File(root.parentFile, "history/" + Math.abs(rel.hashCode()) + "_" + safe)
        dir.mkdirs()
        return dir
    }

    fun list(root: File, f: File): List<Snap> {
        val files = dirFor(root, f).listFiles() ?: return emptyList()
        return files.mapNotNull { x ->
            val m = NAME.matchEntire(x.name) ?: return@mapNotNull null
            Snap(m.groupValues[1].toLong(), m.groupValues[2], x)
        }.sortedByDescending { it.time }
    }

    fun read(s: Snap): String =
        GZIPInputStream(s.file.inputStream()).use { String(it.readBytes(), Charsets.UTF_8) }

    /** true, если снимок создан (если текст не отличается от прошлого снимка, ничего не пишется). */
    fun snapshot(root: File, f: File, text: String, reason: String): Boolean {
        val last = list(root, f).firstOrNull()
        if (last != null && read(last) == text) return false
        val out = File(dirFor(root, f), System.currentTimeMillis().toString() + "_" + reason + ".gz")
        GZIPOutputStream(out.outputStream()).use { it.write(text.toByteArray(Charsets.UTF_8)) }
        list(root, f).drop(MAX).forEach { it.file.delete() }
        return true
    }
}
