package com.pyide

import android.content.Context
import android.graphics.Typeface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontFamily

/**
 * Моноширинный шрифт редактора. JetBrains Mono (шрифт PyCharm, лицензия SIL OFL 1.1,
 * текст лицензии рядом в assets/fonts) вшит в приложение. Если не загрузился, используется системный.
 */
object Fonts {
    private var jb by mutableStateOf<FontFamily?>(null)

    val mono: FontFamily
        get() = if (Prefs.jbFont) (jb ?: FontFamily.Monospace) else FontFamily.Monospace

    fun init(ctx: Context) {
        jb = try {
            FontFamily(Typeface.createFromAsset(ctx.assets, "fonts/JetBrainsMono-Regular.ttf"))
        } catch (e: Exception) {
            null
        }
    }
}
