package com.pyide

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = AndroidColor.TRANSPARENT
        window.navigationBarColor = AndroidColor.TRANSPARENT
        window.decorView.setBackgroundColor(0xFF0B0B0D.toInt())
        Prefs.init(this)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        val root = File(filesDir, "project").apply { mkdirs() }
        val site = File(filesDir, "site-packages").apply { mkdirs() }
        Backend.init(root.absolutePath, site.absolutePath)
        Fonts.init(this)
        Backend.pluginInit(File(filesDir, "plugins").absolutePath, root.absolutePath)
        Backend.pluginSafeMode(Prefs.safeMode)

        if (root.listFiles().isNullOrEmpty()) {
            File(root, "main.py").writeText(
                "name = input(\"Как тебя зовут? \")\n" +
                    "for i in range(3):\n" +
                    "    print(\"Привет,\", name, i)\n"
            )
        }
        val ide = Ide(root)
        ide.refresh()
        ide.panelOpen = false   // сначала всё место отдаём редактору; шторка откроется при запуске
        (ide.files.firstOrNull { it.name == "main.py" } ?: ide.files.firstOrNull())
            ?.let { ide.open(it) }

        setContent {
            DsTheme { MainScreen(ide) }
        }
    }
}
