package com.pyide

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Все иконки приложения нарисованы вручную на сетке 24x24: ни эмодзи, ни готовых наборов. */
enum class Ic {
    Play, Debug, Stop, Menu, More, Folder, FolderOpen, File, Close, Plus,
    ChevronRight, ChevronDown, ChevronUp, Undo, Redo, Search, Branch, Terminal,
    Warning, Trash, Pencil, StepOver, StepInto, StepOut, Resume, Tab, Check,
    Refresh, Structure, Send, ChevronLeft, Plugin, Gear, Shield
}

@Composable
fun DsIcon(kind: Ic, tint: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) { drawIcon(kind, tint) }
}

private fun DrawScope.drawIcon(kind: Ic, c: Color) {
    val u = size.minDimension / 24f
    val sw = 2f * u
    val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)

    fun o(x: Float, y: Float) = Offset(x * u, y * u)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
        drawLine(c, o(x1, y1), o(x2, y2), strokeWidth = sw, cap = StrokeCap.Round)

    fun poly(vararg p: Float, close: Boolean = false, fill: Boolean = false) {
        val path = Path()
        path.moveTo(p[0] * u, p[1] * u)
        var i = 2
        while (i < p.size) {
            path.lineTo(p[i] * u, p[i + 1] * u)
            i += 2
        }
        if (close) path.close()
        if (fill) drawPath(path, c)
        drawPath(path, c, style = st)
    }

    fun dot(x: Float, y: Float, r: Float) = drawCircle(c, r * u, o(x, y))
    fun ring(x: Float, y: Float, r: Float) = drawCircle(c, r * u, o(x, y), style = st)

    when (kind) {
        Ic.Play -> poly(7f, 4.5f, 19f, 12f, 7f, 19.5f, close = true, fill = true)

        Ic.Stop -> drawRoundRect(c, o(6f, 6f), Size(12f * u, 12f * u), CornerRadius(2.5f * u))

        // Debug: треугольник запуска с точкой останова слева (чистая геометрия)
        Ic.Debug -> {
            poly(11f, 5.5f, 20.5f, 12f, 11f, 18.5f, close = true)
            dot(5.5f, 12f, 2.4f)
        }

        Ic.Menu -> {
            line(4f, 7f, 20f, 7f)
            line(4f, 12f, 20f, 12f)
            line(4f, 17f, 20f, 17f)
        }

        Ic.More -> {
            dot(12f, 5f, 1.8f)
            dot(12f, 12f, 1.8f)
            dot(12f, 19f, 1.8f)
        }

        Ic.Folder -> poly(3f, 6.5f, 9f, 6.5f, 11f, 8.5f, 21f, 8.5f, 21f, 18.5f, 3f, 18.5f, close = true)

        Ic.FolderOpen -> {
            poly(3f, 18.5f, 3f, 6.5f, 9f, 6.5f, 11f, 8.5f, 19f, 8.5f, 19f, 11f)
            poly(3f, 18.5f, 5.5f, 11f, 22f, 11f, 19.5f, 18.5f, close = true)
        }

        Ic.File -> {
            poly(6f, 3f, 14f, 3f, 19f, 8f, 19f, 21f, 6f, 21f, close = true)
            poly(14f, 3f, 14f, 8f, 19f, 8f)
        }

        Ic.Close -> {
            line(6f, 6f, 18f, 18f)
            line(18f, 6f, 6f, 18f)
        }

        Ic.Plus -> {
            line(12f, 5f, 12f, 19f)
            line(5f, 12f, 19f, 12f)
        }

        Ic.ChevronRight -> poly(9f, 6f, 15f, 12f, 9f, 18f)
        Ic.ChevronDown -> poly(6f, 9f, 12f, 15f, 18f, 9f)
        Ic.ChevronUp -> poly(6f, 15f, 12f, 9f, 18f, 15f)

        Ic.Undo -> {
            poly(9.5f, 6.5f, 5f, 11f, 9.5f, 15.5f)
            val p = Path()
            p.moveTo(5.5f * u, 11f * u)
            p.lineTo(14f * u, 11f * u)
            p.cubicTo(17.5f * u, 11f * u, 20f * u, 13f * u, 20f * u, 16f * u)
            p.cubicTo(20f * u, 19f * u, 17.5f * u, 20f * u, 15f * u, 20f * u)
            drawPath(p, c, style = st)
        }

        Ic.Redo -> scale(-1f, 1f) { drawIcon(Ic.Undo, c) }

        Ic.Search -> {
            ring(10.5f, 10.5f, 6f)
            line(15f, 15f, 20f, 20f)
        }

        Ic.Branch -> {
            ring(7f, 5.5f, 2.3f)
            ring(7f, 18.5f, 2.3f)
            ring(17f, 9f, 2.3f)
            line(7f, 7.8f, 7f, 16.2f)
            val p = Path()
            p.moveTo(17f * u, 11.3f * u)
            p.cubicTo(17f * u, 15f * u, 7f * u, 12f * u, 7f * u, 15f * u)
            drawPath(p, c, style = st)
        }

        Ic.Terminal -> {
            drawRoundRect(c, o(3f, 5f), Size(18f * u, 14f * u), CornerRadius(3f * u), style = st)
            poly(7f, 10f, 10.5f, 12.5f, 7f, 15f)
            line(12.5f, 15.5f, 16.5f, 15.5f)
        }

        Ic.Warning -> {
            poly(12f, 4f, 21f, 19.5f, 3f, 19.5f, close = true)
            line(12f, 10f, 12f, 14f)
            dot(12f, 16.8f, 1f)
        }

        Ic.Trash -> {
            line(5f, 7f, 19f, 7f)
            poly(9.5f, 7f, 9.5f, 4.5f, 14.5f, 4.5f, 14.5f, 7f)
            poly(6.5f, 7f, 7.5f, 20f, 16.5f, 20f, 17.5f, 7f)
            line(10.5f, 10.5f, 10.5f, 16.5f)
            line(13.5f, 10.5f, 13.5f, 16.5f)
        }

        Ic.Pencil -> {
            poly(4f, 20f, 4.8f, 15.5f, 15.5f, 4.8f, 19.2f, 8.5f, 8.5f, 19.2f, close = true)
            line(13f, 7.3f, 16.7f, 11f)
        }

        Ic.StepOver -> {
            val p = Path()
            p.moveTo(4.5f * u, 14f * u)
            p.cubicTo(4.5f * u, 4.5f * u, 19.5f * u, 4.5f * u, 19.5f * u, 14f * u)
            drawPath(p, c, style = st)
            poly(16.5f, 11f, 19.5f, 14.2f, 22.5f, 11f)
            dot(12f, 19.5f, 1.8f)
        }

        Ic.StepInto -> {
            line(12f, 3.5f, 12f, 14f)
            poly(7.5f, 10f, 12f, 14.5f, 16.5f, 10f)
            dot(12f, 19.5f, 1.8f)
        }

        Ic.StepOut -> {
            dot(12f, 19.5f, 1.8f)
            line(12f, 15f, 12f, 4.5f)
            poly(7.5f, 9f, 12f, 4.5f, 16.5f, 9f)
        }

        Ic.Resume -> {
            line(5.5f, 5f, 5.5f, 19f)
            poly(10f, 5f, 19f, 12f, 10f, 19f, close = true, fill = true)
        }

        Ic.Tab -> {
            line(4f, 12f, 17f, 12f)
            poly(12.5f, 7.5f, 17f, 12f, 12.5f, 16.5f)
            line(20.5f, 6f, 20.5f, 18f)
        }

        Ic.Check -> poly(5f, 12.5f, 10f, 17.5f, 19f, 7f)

        Ic.Refresh -> {
            drawArc(
                c, startAngle = -45f, sweepAngle = 280f, useCenter = false,
                topLeft = o(4.5f, 4.5f), size = Size(15f * u, 15f * u), style = st
            )
            poly(17.3f, 2.8f, 17.3f, 6.7f, 13.4f, 6.7f)
        }

        Ic.Structure -> {
            dot(5f, 6f, 1.4f)
            dot(8f, 12f, 1.4f)
            dot(8f, 18f, 1.4f)
            line(9f, 6f, 20f, 6f)
            line(12f, 12f, 20f, 12f)
            line(12f, 18f, 20f, 18f)
        }

        Ic.Send -> poly(4f, 4.5f, 20f, 12f, 4f, 19.5f, 8f, 12f, close = true)

        Ic.ChevronLeft -> poly(15f, 6f, 9f, 12f, 15f, 18f)

        // штепсель: два контакта, корпус и провод
        Ic.Plugin -> {
            line(9f, 3f, 9f, 8f)
            line(15f, 3f, 15f, 8f)
            drawRoundRect(c, o(5f, 8f), Size(14f * u, 8f * u), CornerRadius(3f * u), style = st)
            line(12f, 16f, 12f, 21f)
        }

        // шестерёнка: кольцо, втулка и восемь зубцов
        Ic.Gear -> {
            ring(12f, 12f, 6f)
            ring(12f, 12f, 2.4f)
            for (k in 0 until 8) {
                val a = k * Math.PI / 4
                val cx = Math.cos(a).toFloat()
                val cy = Math.sin(a).toFloat()
                line(12f + 6f * cx, 12f + 6f * cy, 12f + 9f * cx, 12f + 9f * cy)
            }
        }

        Ic.Shield -> poly(12f, 3f, 19f, 6f, 19f, 12f, 12f, 21f, 5f, 12f, 5f, 6f, close = true)
    }
}
