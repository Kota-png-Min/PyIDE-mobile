package com.pyide

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

// ======================= Редактор =======================

/** Для каждой визуальной строки (с учётом переноса и подсказок типов) вернуть номер логической строки, 0 для продолжения. */
private fun gutterRows(expectedLen: Int, layout: TextLayoutResult?, plain: String): IntArray {
    if (layout == null || layout.layoutInput.text.text.length != expectedLen) {
        val n = plain.count { it == '\n' } + 1
        return IntArray(n) { it + 1 }
    }
    val shown = layout.layoutInput.text.text
    val out = IntArray(layout.lineCount)
    var logical = 0
    for (i in 0 until layout.lineCount) {
        val start = layout.getLineStart(i)
        val first = start == 0 || shown.getOrNull(start - 1) == '\n'
        if (first) {
            logical++
            out[i] = logical
        }
    }
    return out
}

private val HintStyle = SpanStyle(color = Color(0xFF6B6F76), fontStyle = FontStyle.Italic)
private val GhostStyle = SpanStyle(color = Color(0xFF5C6168))

/** Серая вставка в показываемый текст: подсказка типа (ghost = false) или призрачное окончание слова. */
private data class Inlay(val offset: Int, val text: String, val ghost: Boolean)

/** Вставляет серые надписи в показываемый текст и согласует позиции курсора. */
private fun withHints(base: AnnotatedString, inlays: List<Inlay>): TransformedText {
    if (inlays.isEmpty()) return TransformedText(base, OffsetMapping.Identity)
    val b = AnnotatedString.Builder()
    var pos = 0
    for (g in inlays) {
        b.append(base.subSequence(pos, g.offset))
        b.pushStyle(if (g.ghost) GhostStyle else HintStyle)
        b.append(g.text)
        b.pop()
        pos = g.offset
    }
    b.append(base.subSequence(pos, base.length))
    val mapping = object : OffsetMapping {
        override fun originalToTransformed(offset: Int): Int {
            var shift = 0
            for (g in inlays) if (g.offset < offset) shift += g.text.length
            return offset + shift
        }

        override fun transformedToOriginal(offset: Int): Int {
            var shift = 0
            for (g in inlays) {
                val start = g.offset + shift
                if (offset <= start) break
                if (offset < start + g.text.length) return g.offset
                shift += g.text.length
            }
            return offset - shift
        }
    }
    return TransformedText(b.toAnnotatedString(), mapping)
}

@Composable
fun EditorPane(ide: Ide, f: File, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val v = ide.texts[f.path] ?: TextFieldValue("")
    val density = LocalDensity.current
    val fs = Prefs.fontSize
    val lhSp = (fs * 1.4f).sp
    val lhPx = with(density) { lhSp.toPx() }
    val vs = rememberScrollState()
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }

    val probs = ide.problems[f.path].orEmpty()
    val errLines = remember(probs) { probs.map { it.line }.toSet() }
    val pause = ide.runState.pause
    val dbgLine = if (pause != null && pause.file == f.path) pause.line else -1
    val match = ide.match
    val hintSet = ide.hints[f.path]

    // призрачный текст: окончание первой подсказки, только после слова и только если подсказки свежие
    val ghostText = run {
        val list = ide.suggestions
        val pos = v.selection.start
        val c = if (pos > 0 && pos <= v.text.length) v.text[pos - 1] else ' '
        if (!Prefs.ghost || list.isEmpty() || !v.selection.collapsed ||
            !(c.isLetterOrDigit() || c == '_') || ide.suggestKey != ide.suggestKeyOf(v)
        ) ""
        else {
            val top = list[0]
            top.rest + (if (top.type == "function" || top.type == "class") "(" else "")
        }
    }

    val inlays: List<Inlay> = remember(hintSet, v.text, v.selection.start, ghostText, Prefs.hints) {
        val out = mutableListOf<Inlay>()
        if (Prefs.hints && hintSet != null && hintSet.text == v.text) {
            for (h in hintSet.items) {
                val ls = offsetOfLine(v.text, h.line)
                val le = v.text.indexOf('\n', ls).let { if (it < 0) v.text.length else it }
                val off = ls + h.col
                if (off in ls..le) out.add(Inlay(off, h.text, false))
            }
        }
        if (ghostText.isNotEmpty()) out.add(Inlay(v.selection.start, ghostText, true))
        out.sortedWith(compareBy<Inlay>({ it.offset }, { it.ghost }))
    }
    val hintTotal = inlays.sumOf { it.text.length }
    val transform = remember(errLines, dbgLine, match, inlays) {
        VisualTransformation { text ->
            withHints(highlight(text.text, errLines, dbgLine, match), inlays)
        }
    }

    LaunchedEffect(v.text) {
        delay(700)
        ide.lint(f)
    }
    LaunchedEffect(v.text, Prefs.hints) {
        if (!Prefs.hints) return@LaunchedEffect
        delay(900)
        ide.refreshHints(f)
    }
    LaunchedEffect(v.text, v.selection) {
        val pos = v.selection.start
        val c = if (pos > 0 && pos <= v.text.length) v.text[pos - 1] else ' '
        val ok = v.selection.collapsed && (c.isLetterOrDigit() || c == '_' || c == '.')
        if (!ok) {
            ide.suggestions = emptyList()
            return@LaunchedEffect
        }
        delay(300)
        ide.complete(f)
    }
    LaunchedEffect(ide.scrollLine) {
        if (ide.scrollLine >= 0) {
            delay(60)
            vs.animateScrollTo(((ide.scrollLine - 3).coerceAtLeast(0) * lhPx).toInt())
            ide.scrollLine = -1
        }
    }

    val rows = remember(layout, v.text, hintTotal) { gutterRows(v.text.length + hintTotal, layout, v.text) }
    val bps = ide.breakpoints[f.path].orEmpty()
    val layoutOk = layout != null && layout?.layoutInput?.text?.text?.length == v.text.length + hintTotal
    val shownCursor = v.selection.start + inlays.filter { it.offset < v.selection.start }.sumOf { it.text.length }
    val curVisual = if (layoutOk && v.selection.start <= v.text.length)
        layout?.getLineForOffset(shownCursor) ?: 0 else 0

    val gutter = remember(rows, bps, dbgLine) {
        buildAnnotatedString {
            rows.forEachIndexed { i, n ->
                if (n > 0) {
                    val col = if (n == dbgLine) Ds.orange else if (n in bps) Color.White else Ds.gray
                    withStyle(SpanStyle(color = col)) { append(n.toString()) }
                }
                if (i < rows.size - 1) append("\n")
            }
        }
    }
    val textStyle = TextStyle(
        fontFamily = Fonts.mono, fontSize = fs.sp, lineHeight = lhSp,
        color = Color(0xFFA9B7C6)
    )

    Box(modifier.background(Ds.editor)) {
        Row(
            Modifier
                .fillMaxSize()
                .verticalScroll(vs)
                .drawBehind {
                    val top = 8.dp.toPx()
                    // подсветка текущей строки
                    if (layoutOk) {
                        drawRect(Color(0x14FFFFFF), Offset(0f, top + curVisual * lhPx), Size(size.width, lhPx))
                    }
                    rows.forEachIndexed { i, n ->
                        if (n > 0 && n in bps) {
                            drawCircle(Ds.red, 6.dp.toPx(), Offset(14.dp.toPx(), top + (i + 0.5f) * lhPx))
                        }
                        if (n > 0 && n == dbgLine) {
                            drawRect(Ds.orange, Offset(0f, top + i * lhPx), Size(3.dp.toPx(), lhPx))
                        }
                    }
                }
                .padding(top = 8.dp, bottom = 160.dp)
        ) {
            // жёлоб: тап по номеру ставит / снимает точку останова
            Box(
                Modifier
                    .width(56.dp)
                    .pointerInput(rows) {
                        detectTapGestures { off ->
                            val vis = (off.y / lhPx).toInt()
                            val n = rows.getOrNull(vis) ?: 0
                            if (n > 0) {
                                ide.toggleBreak(f, n)
                                val set = ide.breakpoints[f.path].orEmpty()
                                scope.launch(Dispatchers.IO) {
                                    try { Backend.setBreaks(f.absolutePath, set) } catch (_: Exception) {}
                                }
                            }
                        }
                    }
            ) {
                Text(
                    gutter,
                    style = textStyle.copy(color = Ds.gray, textAlign = TextAlign.End),
                    softWrap = false,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 10.dp)
                )
            }
            BasicTextField(
                value = v,
                onValueChange = { n -> ide.edit(f, autoIndent(v, n)) },
                textStyle = textStyle,
                cursorBrush = SolidColor(Ds.orange),
                visualTransformation = transform,
                onTextLayout = { layout = it },
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.None,
                    autoCorrectEnabled = false
                ),
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 12.dp)
                    .heightIn(min = 300.dp)
                    .onPreviewKeyEvent { e ->
                        if (e.type == KeyEventType.KeyDown && e.key == Key.Tab) {
                            scope.launch { ide.tab(f) }
                            true
                        } else false
                    }
            )
        }
    }
}

// ======================= Всплывающие подсказки =======================

private fun badgeOf(type: String): Pair<String, Color> = when (type) {
    "function" -> "f" to Ds.orange
    "class" -> "C" to Color(0xFFFFC66D)
    "module" -> "m" to Color(0xFF6897BB)
    "keyword" -> "k" to Color(0xFFCC7832)
    "instance", "param", "statement" -> "v" to Color(0xFF9876AA)
    else -> "-" to Ds.gray
}

/** Окно подсказок над клавиатурой. Тап по строке подставляет вариант. */
@Composable
fun CompletionPopup(ide: Ide, f: File?, modifier: Modifier = Modifier) {
    val list = ide.suggestions
    val haptic = LocalHapticFeedback.current
    if (f == null || list.isEmpty()) return
    Column(
        modifier
            .widthIn(max = 340.dp)
            .heightIn(max = 216.dp)
            .outlinedCard(18.dp)
    ) {
        LazyColumn {
            items(list) { c ->
                val (letter, color) = badgeOf(c.type)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 44.dp)
                        .clickable {
                            if (Prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val cur = ide.texts[f.path]
                            if (cur != null) {
                                val extra = if (c.type == "function" || c.type == "class") "(" else ""
                                ide.edit(f, insertAt(cur, c.rest + extra))
                            }
                            ide.suggestions = emptyList()
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(color.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(letter, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        c.name, style = Ds.body.copy(fontFamily = Fonts.mono, fontSize = 15.sp),
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

// ======================= Панель быстрых символов =======================

private val OPEN_TO_CLOSE = mapOf('(' to ')', '[' to ']', '{' to '}')

/** Умная вставка: пары скобок и кавычек, перешагивание закрывающего символа, обёртка выделения. */
fun smartInsert(v: TextFieldValue, s: String): TextFieldValue {
    val ch = s.singleOrNull() ?: return insertAt(v, s)
    val t = v.text
    val a = v.selection.min
    val b = v.selection.max
    val next = t.getOrNull(b)
    val prev = t.getOrNull(a - 1)
    return when {
        ch in OPEN_TO_CLOSE -> {
            val close = OPEN_TO_CLOSE.getValue(ch)
            if (a != b) v.copy(
                text = t.substring(0, a) + ch + t.substring(a, b) + close + t.substring(b),
                selection = TextRange(a + 1, b + 1)
            ) else v.copy(
                text = t.substring(0, a) + ch + close + t.substring(a),
                selection = TextRange(a + 1)
            )
        }
        ch == ')' || ch == ']' || ch == '}' ->
            if (a == b && next == ch) v.copy(selection = TextRange(a + 1)) else insertAt(v, s)
        ch == '"' || ch == '\'' -> when {
            a == b && next == ch -> v.copy(selection = TextRange(a + 1))
            a != b -> v.copy(
                text = t.substring(0, a) + ch + t.substring(a, b) + ch + t.substring(b),
                selection = TextRange(a + 1, b + 1)
            )
            ch == '\'' && prev != null && prev.isLetterOrDigit() -> insertAt(v, s)
            else -> v.copy(
                text = t.substring(0, a) + ch + ch + t.substring(a),
                selection = TextRange(a + 1)
            )
        }
        else -> insertAt(v, s)
    }
}

@Composable
private fun SymKey(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .widthIn(min = 44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Ds.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = Ds.body.copy(fontFamily = Fonts.mono, fontSize = 18.sp))
    }
}

@Composable
fun QuickSymbolBar(ide: Ide, f: File) {
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val syms = remember(Prefs.symbols) { Prefs.symbols.map { it.toString() } }
    LazyRow(
        Modifier
            .fillMaxWidth()
            .background(Ds.bg),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        item { DsIconButton(Ic.Undo, onClick = { ide.undo(f) }, size = 44.dp) }
        item { DsIconButton(Ic.Redo, onClick = { ide.redo(f) }, size = 44.dp) }
        item {
            // Tab делает то же, что физическая клавиша: дополнение или отступ
            DsButton(
                "Tab",
                onClick = {
                    if (Prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    scope.launch { ide.tab(f) }
                },
                kind = DsBtn.Outlined, icon = Ic.Tab
            )
        }
        items(syms) { s ->
            SymKey(s) {
                val cur = ide.texts[f.path]
                if (cur != null) ide.edit(f, smartInsert(cur, s))
            }
        }
    }
}

// ======================= Поиск / замена =======================

@Composable
fun FindBar(ide: Ide, f: File) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Ds.surface)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DsField(ide.findText, { ide.findText = it }, "Найти", Modifier.weight(1f))
            DsIconButton(Ic.ChevronUp, onClick = { ide.findNext(f, false) }, size = 44.dp)
            DsIconButton(Ic.ChevronDown, onClick = { ide.findNext(f, true) }, size = 44.dp)
            DsIconButton(Ic.Close, onClick = { ide.findOpen = false; ide.match = null }, size = 44.dp)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DsField(ide.replaceText, { ide.replaceText = it }, "Заменить на", Modifier.weight(1f))
            DsButton("Заменить", onClick = { ide.replaceOne(f) }, kind = DsBtn.Gray)
            DsButton("Все", onClick = { ide.replaceAll(f) }, kind = DsBtn.Outlined)
        }
    }
}

// ======================= Статус-строка =======================

@Composable
fun StatusBar(ide: Ide, f: File) {
    val v = ide.texts[f.path]
    val pos = v?.selection?.start ?: 0
    val line = if (v != null) lineOf(v.text, pos) else 1
    val col = if (v != null) pos - (v.text.lastIndexOf('\n', pos - 1) + 1) else 0
    val probs = ide.problems[f.path].orEmpty()
    val err = probs.firstOrNull { it.line == line }
    Row(
        Modifier
            .fillMaxWidth()
            .background(Ds.bg)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("$line:${col + 1}", style = Ds.caption)
        if (probs.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                DsIcon(Ic.Warning, Ds.orange, 14.dp)
                Text("${probs.size}", style = Ds.caption, color = Ds.orange)
            }
        }
        Text(
            err?.msg ?: ide.status,
            style = Ds.caption,
            color = if (err != null) Ds.red else Ds.gray,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
    }
}
