import ast
import bdb
import code
import ctypes
import difflib
import importlib
import io
import json
import os
import queue
import re
import shlex
import shutil
import sys
import threading
import time
import traceback
import types
import urllib.request
import zipfile

ROOT = ""
SITE = ""


def init(root, site):
    global ROOT, SITE
    ROOT, SITE = root, site
    os.makedirs(site, exist_ok=True)
    for p in (root, site):
        if p not in sys.path:
            sys.path.insert(0, p)
    os.chdir(root)
    repl_reset()


# ====================== Запуск / отладка ======================

class Out:
    encoding = "utf-8"
    errors = "replace"

    def __init__(self, s):
        self.s = s

    def write(self, t):
        if t:
            self.s._emit(t)
        return len(t)

    def flush(self):
        pass

    def isatty(self):
        return False


class In:
    encoding = "utf-8"

    def __init__(self, s):
        self.s = s

    def readline(self, size=-1):
        return self.s._wait_input()

    def read(self, size=-1):
        return ""

    def isatty(self):
        return False

    def __iter__(self):
        return self

    def __next__(self):
        line = self.readline()
        if not line:
            raise StopIteration
        return line


class Dbg(bdb.Bdb):
    def __init__(self, s):
        super().__init__()
        self.s = s
        self.cmds = queue.Queue()
        self.first = True

    def _mine(self, frame):
        fn = frame.f_code.co_filename
        return bool(ROOT) and fn.startswith(ROOT)

    def stop_here(self, frame):
        if not self._mine(frame):
            return False
        return super().stop_here(frame)

    def user_line(self, frame):
        if self.first:
            self.first = False
            if not self.break_here(frame):
                self.set_continue()
                return
        self.s._pause(self, frame)


class Session:
    def __init__(self):
        self.lock = threading.Lock()
        self.buf = []
        self.thread = None
        self.running = False
        self.waiting_input = False
        self.stop_flag = False
        self.inq = queue.Queue()
        self.dbg = None
        self.pause = None
        self.pause_frame = None
        self.pause_id = 0
        self.breaks = {}

    # ---- вывод / ввод ----
    def _emit(self, t):
        with self.lock:
            self.buf.append(t)

    def drain(self):
        with self.lock:
            s = "".join(self.buf)
            self.buf.clear()
            return s

    def _wait_input(self):
        self.waiting_input = True
        try:
            while True:
                try:
                    line = self.inq.get(timeout=0.2)
                except queue.Empty:
                    if self.stop_flag:
                        return ""
                    continue
                self._emit(line + "\n")
                return line + "\n"
        finally:
            self.waiting_input = False

    # ---- запуск ----
    def start(self, path, debug, args=""):
        if self.running:
            return
        import linecache
        linecache.checkcache()
        self.stop_flag = False
        self.pause = None
        while not self.inq.empty():
            self.inq.get_nowait()
        self.running = True
        self.thread = threading.Thread(target=self._main, args=(path, debug, args), daemon=True)
        self.thread.start()

    def _main(self, path, debug, args=""):
        old_io = (sys.stdout, sys.stderr, sys.stdin)
        old_main = sys.modules.get("__main__")
        old_cwd = os.getcwd()
        old_argv = sys.argv
        folder = os.path.dirname(path)
        t0 = time.time()
        sys.stdout = sys.stderr = Out(self)
        sys.stdin = In(self)
        try:
            sys.argv = [path] + shlex.split(args or "")
        except ValueError:
            sys.argv = [path]
        os.chdir(folder)
        if folder not in sys.path:
            sys.path.insert(0, folder)
        try:
            with open(path, encoding="utf-8") as f:
                src = f.read()
            mod = types.ModuleType("__main__")
            mod.__file__ = path
            sys.modules["__main__"] = mod
            codeobj = compile(src, path, "exec")
            if debug:
                self.dbg = Dbg(self)
                for p, ls in self.breaks.items():
                    for l in ls:
                        self.dbg.set_break(p, l)
                self.dbg.run(codeobj, mod.__dict__)
            else:
                exec(codeobj, mod.__dict__)
        except SystemExit:
            pass
        except KeyboardInterrupt:
            self._emit("\n[остановлено]\n")
        except BaseException:
            etype, e, tb = sys.exc_info()
            while tb is not None and tb.tb_frame.f_code.co_filename != path:
                tb = tb.tb_next
            if tb is None:
                self._emit("".join(traceback.format_exception_only(etype, e)))
            else:
                self._emit("".join(traceback.format_exception(etype, e, tb)))
        finally:
            sys.stdout, sys.stderr, sys.stdin = old_io
            sys.argv = old_argv
            if old_main is not None:
                sys.modules["__main__"] = old_main
            try:
                os.chdir(old_cwd)
            except Exception:
                pass
            for name, m in list(sys.modules.items()):
                fn = getattr(m, "__file__", None)
                if fn and fn.startswith(ROOT) and name != "__main__":
                    sys.modules.pop(name, None)
            self._emit("\n[завершено за %.1f c]\n" % (time.time() - t0))
            with self.lock:
                self.running = False
                self.pause = None
            self.dbg = None
            self.pause_frame = None

    # ---- отладчик ----
    def _pause(self, dbg, frame):
        stack = []
        f = frame
        while f is not None:
            fn = f.f_code.co_filename
            if fn.startswith(ROOT):
                stack.append({"file": fn, "line": f.f_lineno, "fn": f.f_code.co_name})
            f = f.f_back
        skip = (types.ModuleType, types.FunctionType, types.BuiltinFunctionType, type)
        vs = []
        for k, v in list(frame.f_locals.items()):
            if k.startswith("__") or isinstance(v, skip):
                continue
            try:
                r = repr(v)
            except Exception:
                r = "<?>"
            vs.append([k, type(v).__name__, r[:200]])
        self.pause_id += 1
        info = {"id": self.pause_id, "file": frame.f_code.co_filename,
                "line": frame.f_lineno, "stack": stack, "vars": vs}
        self.pause_frame = frame
        with self.lock:
            self.pause = info
        cmd = dbg.cmds.get()
        with self.lock:
            self.pause = None
        self.pause_frame = None
        if cmd == "c":
            dbg.set_continue()
        elif cmd == "n":
            dbg.set_next(frame)
        elif cmd == "s":
            dbg.set_step()
        elif cmd == "r":
            dbg.set_return(frame)
        else:
            dbg.set_quit()

    def dbg_cmd(self, c):
        d = self.dbg
        if d is not None and self.pause is not None:
            d.cmds.put(c)

    def eval_expr(self, expr):
        fr = self.pause_frame
        if fr is None:
            return "программа не на паузе"
        try:
            return repr(eval(expr, fr.f_globals, fr.f_locals))[:500]
        except BaseException as e:
            return "%s: %s" % (type(e).__name__, e)

    def set_breaks(self, path, csv):
        lines = {int(x) for x in csv.split(",") if x.strip()}
        self.breaks[path] = lines
        d = self.dbg
        if d is not None:
            try:
                d.clear_all_file_breaks(path)
                for l in lines:
                    d.set_break(path, l)
            except Exception:
                pass

    # ---- стоп / состояние ----
    def stop(self):
        if not self.running:
            return
        self.stop_flag = True
        paused = self.pause is not None
        if self.dbg is not None:
            self.dbg.cmds.put("q")
        t = self.thread
        if t is not None and t.ident and not paused:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(
                ctypes.c_ulong(t.ident), ctypes.py_object(KeyboardInterrupt))

    def state(self):
        with self.lock:
            return json.dumps({"running": self.running,
                               "input": self.waiting_input,
                               "pause": self.pause})


S = Session()


def start(path, debug, args=""):
    S.start(path, bool(debug), args)


def drain():
    return S.drain()


def state():
    return S.state()


def send_input(line):
    S.inq.put(line)


def stop():
    S.stop()


def dbg_cmd(c):
    S.dbg_cmd(c)


def dbg_eval(e):
    return S.eval_expr(e)


def set_breaks(path, csv):
    S.set_breaks(path, csv)


# ====================== Терминал (REPL) ======================

_repl = None


def repl_reset():
    global _repl
    _repl = code.InteractiveConsole({"__name__": "__console__"})


def repl_push(line):
    if S.running:
        return json.dumps({"out": "Сначала остановите запущенную программу\n", "more": False})
    out = io.StringIO()
    old = (sys.stdout, sys.stderr)
    sys.stdout = sys.stderr = out
    try:
        more = _repl.push(line)
    except BaseException:
        out.write(traceback.format_exc())
        more = False
    finally:
        sys.stdout, sys.stderr = old
    return json.dumps({"out": out.getvalue(), "more": bool(more)})


# ====================== Умный редактор ======================

def lint(src, path):
    try:
        tree = ast.parse(src, path)
    except SyntaxError as e:
        return json.dumps([[e.lineno or 1, max((e.offset or 1) - 1, 0), "SyntaxError: " + str(e.msg)]])
    res = []
    try:
        from pyflakes import checker
        w = checker.Checker(tree, path)
        for m in sorted(w.messages, key=lambda m: (m.lineno, m.col)):
            res.append([m.lineno, m.col, m.message % m.message_args])
    except Exception:
        pass
    return json.dumps(res)


_KW = ("False None True and as assert async await break class continue def del elif else "
       "except finally for from global if import in is lambda nonlocal not or pass raise "
       "return try while with yield print len range str int float list dict set tuple open "
       "input enumerate zip map filter sorted sum min max abs isinstance").split()


def _fallback(src, line, col):
    lines = src.split("\n")
    cur = lines[line - 1][:col] if 0 < line <= len(lines) else ""
    m = re.search(r"([A-Za-z_]\w*)$", cur)
    if not m:
        return []
    pref = m.group(1)
    words = set(_KW) | set(re.findall(r"[A-Za-z_]\w*", src))
    return [[w, w[len(pref):], "word"] for w in sorted(words)
            if w.startswith(pref) and w != pref][:30]


def complete(src, line, col, path):
    try:
        import jedi
        from jedi.api.environment import InterpreterEnvironment
        s = jedi.Script(src, path=path, environment=InterpreterEnvironment(),
                        project=jedi.Project(ROOT))
        out = [[c.name, c.complete or "", c.type] for c in s.complete(line, col)[:40]]
        if out:
            return json.dumps(out)
    except Exception:
        pass
    return json.dumps(_fallback(src, line, col))


def goto(src, line, col, path):
    try:
        import jedi
        from jedi.api.environment import InterpreterEnvironment
        s = jedi.Script(src, path=path, environment=InterpreterEnvironment(),
                        project=jedi.Project(ROOT))
        out = []
        for d in s.goto(line, col, follow_imports=True):
            if d.module_path and d.line:
                out.append([str(d.module_path), d.line, d.column or 0])
        return json.dumps(out)
    except Exception:
        return "[]"


def format_code(src):
    try:
        import autopep8
        return autopep8.fix_code(src)
    except Exception:
        return src


# ====================== pip во время работы ======================
# 1) чисто-Python wheel с PyPI;
# 2) иначе нативный wheel из репозитория Chaquopy (тот же ABI, что у нашего Python),
#    например pandas, pillow, scipy. Компилировать ничего не нужно.

CHAQUO_INDEXES = ["https://chaquo.com/pypi-13.1/"]
_BUNDLED = {"numpy", "requests", "certifi", "jedi", "parso", "pyflakes", "autopep8",
            "pycodestyle", "dulwich", "urllib3", "idna", "charset-normalizer"}
_done = set()


def _norm(n):
    return re.sub(r"[-_.]+", "-", n).lower()


def _open(url):
    ctx = None
    try:
        import ssl
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass
    return urllib.request.urlopen(url, timeout=60, context=ctx)


def _arch():
    import platform
    m = platform.machine().lower()
    return {"aarch64": "arm64_v8a", "arm64": "arm64_v8a", "x86_64": "x86_64"}.get(m, m)


def _native_url(n):
    from urllib.parse import urljoin, urldefrag
    tag = "cp%d%d" % sys.version_info[:2]
    arch = _arch()
    for base in CHAQUO_INDEXES:
        page = base + n + "/"
        try:
            with _open(page) as r:
                html = r.read().decode("utf-8", "replace")
        except Exception:
            continue
        cands = []
        for href in re.findall(r'href="([^"]+)"', html):
            url = urldefrag(urljoin(page, href))[0]
            fn = url.rsplit("/", 1)[-1]
            if (fn.endswith(".whl") and ("%s-%s-android_" % (tag, tag)) in fn
                    and fn.endswith("_%s.whl" % arch)):
                ver = tuple(int(x) for x in re.findall(r"\d+", fn.split("-")[1]))
                cands.append((ver, url))
        if cands:
            return max(cands)[1]
    return None


def _fetch_wheel(url):
    tmp = os.path.join(SITE, "_dl.whl")
    with _open(url) as r, open(tmp, "wb") as f:
        f.write(r.read())
    meta = ""
    try:
        with zipfile.ZipFile(tmp) as z:
            z.extractall(SITE)
            m = [x for x in z.namelist() if x.endswith(".dist-info/METADATA")]
            if m:
                meta = z.read(m[0]).decode("utf-8", "replace")
    finally:
        os.remove(tmp)
    return meta


def _deps(meta):
    out = []
    for line in meta.splitlines():
        if not line.strip():
            break
        if line.startswith("Requires-Dist:"):
            spec = line.split(":", 1)[1].strip()
            if ";" in spec:
                continue  # условные зависимости (extras, бэкпорты, Windows) пропускаем
            out.append(spec)
    return out


def _install(name, log, depth):
    n = _norm(re.split(r"[<>=!~\[;( ]", name.strip())[0])
    if not n or n in _done or depth > 6:
        return
    _done.add(n)
    if n in _BUNDLED:
        log.append("%s: уже встроен в приложение" % n)
        return
    url, ver, kind = None, "", "pure"
    try:
        with _open("https://pypi.org/pypi/%s/json" % n) as r:
            data = json.load(r)
        pure = [u for u in data["urls"] if u["filename"].endswith("none-any.whl")]
        if pure:
            url, ver = pure[0]["url"], data["info"]["version"]
    except Exception as e:
        log.append("%s: PyPI недоступен (%s)" % (n, e))
    if not url:
        url, kind = _native_url(n), "android"
    if not url:
        log.append("Ошибка: %s: нет ни чисто-Python wheel, ни Android-сборки в репозитории Chaquopy. "
                   "Пакет придётся добавить в app/build.gradle.kts." % n)
        return
    meta = _fetch_wheel(url)
    log.append("Установлено: %s %s [%s]" % (n, ver or url.rsplit("/", 1)[-1], kind))
    for dep in _deps(meta):
        _install(dep, log, depth + 1)


def pip_install(spec):
    log = []
    try:
        for part in re.split(r"[\s,]+", spec.strip()):
            if part:
                _install(part, log, 0)
        importlib.invalidate_caches()
    except Exception as e:
        log.append("Ошибка: %s" % e)
    return "\n".join(log) or "ничего не установлено"


# ====================== Git (dulwich) ======================

def _s(x):
    return x.decode(errors="replace") if isinstance(x, bytes) else str(x)


def _repo_dir(rel):
    d = os.path.normpath(os.path.join(ROOT, rel or "."))
    if not (d == ROOT or d.startswith(ROOT + os.sep)):
        raise ValueError("папка вне проекта")
    return d


def _auth(url, user, token):
    if user and token and url.startswith("https://"):
        from urllib.parse import quote
        return "https://%s:%s@%s" % (quote(user, safe=""), quote(token, safe=""), url[8:])
    return url


def git(cmd, rel, a="", b="", c=""):
    try:
        from dulwich import porcelain
        from dulwich.repo import Repo
        path = _repo_dir(rel)

        if cmd == "init":
            os.makedirs(path, exist_ok=True)
            porcelain.init(path)
            gi = os.path.join(path, ".gitignore")
            if not os.path.exists(gi):
                with open(gi, "w") as f:
                    f.write("__pycache__/\n*.pyc\n")
            return "Репозиторий создан: " + (rel or ".")

        if cmd == "clone":
            url = a.strip()
            name = url.rstrip("/").split("/")[-1].removesuffix(".git") or "repo"
            target = os.path.join(ROOT, name)
            errs = io.BytesIO()
            porcelain.clone(_auth(url, b, c), target, errstream=errs, outstream=io.BytesIO())
            r = Repo(target)
            cfg = r.get_config()
            cfg.set((b"remote", b"origin"), b"url", url.encode())  # без токена на диске
            cfg.write_to_path()
            return "Клонировано в папку: " + name

        repo = Repo(path)

        if cmd == "remote":
            cfg = repo.get_config()
            cfg.set((b"remote", b"origin"), b"url", a.strip().encode())
            cfg.set((b"remote", b"origin"), b"fetch", b"+refs/heads/*:refs/remotes/origin/*")
            cfg.write_to_path()
            return "origin = " + a.strip()

        if cmd == "status":
            st = porcelain.status(repo)
            try:
                br = _s(porcelain.active_branch(repo))
            except Exception:
                br = "?"
            lines = ["ветка: " + br]
            for k, v in st.staged.items():
                for f in v:
                    lines.append("в индексе (%s): %s" % (k, _s(f)))
            for f in st.unstaged:
                lines.append("изменён: " + _s(f))
            for f in st.untracked:
                lines.append("новый: " + _s(f))
            return "\n".join(lines) if len(lines) > 1 else lines[0] + "\nнет изменений"

        if cmd == "commit":
            msg, name, email = a.strip(), b.strip(), c.strip()
            if not msg or not name or not email:
                return "Нужны сообщение, имя и email"
            st = porcelain.status(repo)
            paths = [_s(x) for x in st.unstaged] + [_s(x) for x in st.untracked]
            if paths:
                repo.stage(paths)
            author = ("%s <%s>" % (name, email)).encode()
            sha = porcelain.commit(repo, message=msg.encode(), author=author, committer=author)
            return "Коммит " + _s(sha)[:8]

        if cmd == "log":
            out = []
            for e in repo.get_walker(max_entries=30):
                cm = e.commit
                t = time.strftime("%Y-%m-%d %H:%M", time.localtime(cm.commit_time))
                first = _s(cm.message).strip().split("\n")[0]
                out.append("%s %s %s\n    %s" % (_s(cm.id)[:8], t, _s(cm.author), first))
            return "\n".join(out) or "коммитов нет"

        if cmd == "diff":
            try:
                tree = repo[repo.head()].tree
            except KeyError:
                return "коммитов ещё нет"
            st = porcelain.status(repo)
            files = [_s(x) for x in st.unstaged] + [_s(x) for x in st.staged.get("modify", [])]
            out = []
            for f in files:
                try:
                    _, sha = repo[tree].lookup_path(repo.object_store.__getitem__, f.encode())
                    old = _s(repo[sha].data).splitlines()
                except KeyError:
                    old = []
                full = os.path.join(path, f)
                new = open(full, encoding="utf-8", errors="replace").read().splitlines() \
                    if os.path.exists(full) else []
                out.extend(difflib.unified_diff(old, new, "a/" + f, "b/" + f, lineterm=""))
            return "\n".join(out) or "нет изменений"

        if cmd in ("push", "pull"):
            try:
                url = _s(repo.get_config().get((b"remote", b"origin"), b"url"))
            except KeyError:
                return "Не задан remote origin (кнопка Remote)"
            branch = porcelain.active_branch(repo)
            loc = _auth(url, a, b)
            errs = io.BytesIO()
            ref = [b"refs/heads/" + branch]
            if cmd == "push":
                porcelain.push(repo, loc, ref, outstream=io.BytesIO(), errstream=errs)
            else:
                porcelain.pull(repo, loc, ref, outstream=io.BytesIO(), errstream=errs)
            return ("Push" if cmd == "push" else "Pull") + " выполнен\n" + _s(errs.getvalue())

        return "неизвестная команда"
    except Exception as e:
        return "Ошибка git: %s: %s" % (type(e).__name__, e)


# ====================== Подсказки типов (inlay hints) ======================

_CALL_TYPES = {"len": "int", "str": "str", "int": "int", "float": "float", "bool": "bool",
               "list": "list", "dict": "dict", "set": "set", "tuple": "tuple",
               "input": "str", "range": "range", "sorted": "list", "repr": "str",
               "abs": None, "round": None}


def _tname(n):
    if isinstance(n, ast.Constant):
        v = n.value
        if v is None:
            return "None"
        t = type(v).__name__
        return t if t in ("int", "float", "str", "bool", "bytes", "complex") else None
    if isinstance(n, ast.JoinedStr):
        return "str"
    if isinstance(n, (ast.List, ast.ListComp)):
        return "list"
    if isinstance(n, (ast.Dict, ast.DictComp)):
        return "dict"
    if isinstance(n, (ast.Set, ast.SetComp)):
        return "set"
    if isinstance(n, ast.Tuple):
        return "tuple"
    if isinstance(n, ast.Compare):
        return "bool"
    if isinstance(n, ast.UnaryOp):
        if isinstance(n.op, ast.Not):
            return "bool"
        t = _tname(n.operand)
        return t if t in ("int", "float") else None
    if isinstance(n, ast.BinOp):
        a, b = _tname(n.left), _tname(n.right)
        if a in ("int", "float") and b in ("int", "float"):
            if isinstance(n.op, ast.Div):
                return "float"
            return "float" if "float" in (a, b) else "int"
        if a == "str" and b == "str" and isinstance(n.op, ast.Add):
            return "str"
        if a == "str" and isinstance(n.op, (ast.Mod, ast.Mult)):
            return "str"
        return None
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name):
        return _CALL_TYPES.get(n.func.id)
    return None


def _char_col(lines, lineno, byte_col):
    if lineno - 1 >= len(lines):
        return byte_col
    raw = lines[lineno - 1].encode("utf-8")[:byte_col]
    return len(raw.decode("utf-8", "ignore"))


def inlay_hints(src):
    """Список [строка, столбец, ': тип'] для простых присваиваний и циклов по range."""
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return "[]"
    lines = src.split("\n")
    seen, out = set(), []

    def add(target, text):
        if getattr(target, "end_lineno", None) is None:
            return
        key = (target.end_lineno, target.end_col_offset)
        if key in seen:
            return
        seen.add(key)
        out.append([target.end_lineno, _char_col(lines, target.end_lineno, target.end_col_offset), ": " + text])

    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            t = _tname(node.value)
            if t:
                add(node.targets[0], t)
        elif isinstance(node, ast.For) and isinstance(node.target, ast.Name):
            if isinstance(node.iter, ast.Call) and isinstance(node.iter.func, ast.Name) \
                    and node.iter.func.id == "range":
                add(node.target, "int")
    out.sort()
    return json.dumps(out[:300])


# ====================== Терминал (встроенная оболочка) ======================

_cwd = ""
_git_ident = {"name": "", "email": "", "user": "", "token": ""}


def _cwd_get():
    global _cwd
    if not _cwd:
        _cwd = ROOT
    return _cwd


def _rel_cwd():
    c = _cwd_get()
    r = os.path.relpath(c, ROOT)
    return "~" if r == "." else "~/" + r


def _resolve(p):
    p = p.replace("~", ROOT, 1) if p.startswith("~") else p
    full = os.path.normpath(p if os.path.isabs(p) else os.path.join(_cwd_get(), p))
    if not (full == ROOT or full.startswith(ROOT + os.sep)):
        raise PermissionError("путь вне проекта: " + p)
    return full


_HELP = """Команды:
  ls [-l] [путь]      список файлов        cd <папка>        сменить папку
  pwd                 текущая папка        cat <файл>        показать файл
  mkdir [-p] <папка>  создать папку        touch <файл>      создать файл
  rm [-r] <путь>      удалить              mv/cp <откуда> <куда>
  echo текст [> файл] вывод / запись       clear             очистить экран
  python [файл] [аргументы]   запуск файла; без файла - интерактивный Python (выход: exit())
  pip install|uninstall|list  пакеты (чисто-Python с PyPI и Android-сборки Chaquopy)
  git status|log|diff|init|clone <url>|add .|commit -m "текст"|push|pull
  git config user.name|user.email <значение>    git login <логин> <токен>
"""


def _run_script_capture(path, args):
    if S.running:
        return "Сначала остановите запущенную программу (кнопка Stop).\n"
    out = io.StringIO()
    old = (sys.stdout, sys.stderr, sys.stdin, sys.argv, os.getcwd())
    sys.stdout = sys.stderr = out
    sys.stdin = io.StringIO("")
    sys.argv = [path] + args
    folder = os.path.dirname(path)
    try:
        os.chdir(folder)
        if folder not in sys.path:
            sys.path.insert(0, folder)
        import runpy
        runpy.run_path(path, run_name="__main__")
    except SystemExit:
        pass
    except BaseException:
        out.write(traceback.format_exc())
    finally:
        sys.stdout, sys.stderr, sys.stdin, sys.argv = old[0], old[1], old[2], old[3]
        try:
            os.chdir(old[4])
        except Exception:
            pass
    return out.getvalue()


def _pip_uninstall(names):
    log = []
    for raw in names:
        n = _norm(raw)
        removed = False
        for d in os.listdir(SITE) if os.path.isdir(SITE) else []:
            if d.endswith(".dist-info") and _norm(d.split("-")[0]) == n:
                di = os.path.join(SITE, d)
                rec = os.path.join(di, "RECORD")
                if os.path.exists(rec):
                    for ln in open(rec, encoding="utf-8", errors="replace"):
                        rel = ln.split(",")[0].strip()
                        full = os.path.normpath(os.path.join(SITE, rel))
                        if rel and full.startswith(SITE + os.sep) and os.path.isfile(full):
                            os.remove(full)
                shutil.rmtree(di, ignore_errors=True)
                removed = True
        # убрать пустые папки пакетов
        for root_, dirs, files in os.walk(SITE, topdown=False):
            if root_ != SITE and not os.listdir(root_):
                os.rmdir(root_)
        _done.discard(n)
        log.append(("Удалён " if removed else "Не найден (или встроен в приложение): ") + raw)
    importlib.invalidate_caches()
    return "\n".join(log) + "\n"


def _pip_list():
    rows = []
    if os.path.isdir(SITE):
        for d in sorted(os.listdir(SITE)):
            if d.endswith(".dist-info"):
                nm, _, rest = d[:-len(".dist-info")].partition("-")
                rows.append("%-24s %s" % (nm, rest))
    head = "Установлено через терминал:\n" if rows else "Через терминал пока ничего не установлено.\n"
    return head + "\n".join(rows) + ("\n" if rows else "") + \
        "Встроены в приложение: " + ", ".join(sorted(_BUNDLED)) + "\n"


def _git_cmd(args):
    rel = os.path.relpath(_cwd_get(), ROOT)
    sub = args[0] if args else ""
    rest = args[1:]
    if sub in ("status", "log", "diff", "init", "push", "pull"):
        if sub in ("push", "pull"):
            return git(sub, rel, _git_ident["user"], _git_ident["token"]) + "\n"
        return git(sub, rel) + "\n"
    if sub == "clone" and rest:
        return git("clone", ".", rest[0], _git_ident["user"], _git_ident["token"]) + "\n"
    if sub == "add":
        return "Добавлять вручную не нужно: git commit -m \"текст\" добавляет все изменения.\n"
    if sub == "commit":
        msg = ""
        if "-m" in rest and rest.index("-m") + 1 < len(rest):
            msg = rest[rest.index("-m") + 1]
        if not _git_ident["name"] or not _git_ident["email"]:
            return "Сначала: git config user.name \"Имя\" и git config user.email почта\n"
        return git("commit", rel, msg, _git_ident["name"], _git_ident["email"]) + "\n"
    if sub == "config" and len(rest) >= 2:
        key = rest[0].split(".")[-1]
        if key in ("name", "email"):
            _git_ident[key] = rest[1]
            return "%s = %s\n" % (rest[0], rest[1])
    if sub == "login" and len(rest) >= 2:
        _git_ident["user"], _git_ident["token"] = rest[0], rest[1]
        return "Логин и токен сохранены в памяти (на диск не пишутся).\n"
    if sub == "remote" and len(rest) >= 3 and rest[0] == "add":
        return git("remote", rel, rest[2]) + "\n"
    return "Использование: git status|log|diff|init|clone <url>|commit -m \"текст\"|push|pull|config|login\n"


def shell(line):
    """Выполнить одну команду встроенной оболочки. Возвращает JSON {out, cwd, clear}."""
    global _cwd
    out = io.StringIO()
    clear = False
    try:
        parts = shlex.split(line)
    except ValueError as e:
        parts = []
        out.write("ошибка разбора команды: %s\n" % e)
    if parts:
        cmd, args = parts[0], parts[1:]
        try:
            if cmd == "help":
                out.write(_HELP)
            elif cmd == "pwd":
                out.write(_rel_cwd() + "\n")
            elif cmd == "cd":
                target = _resolve(args[0] if args else "~")
                if not os.path.isdir(target):
                    out.write("нет такой папки: %s\n" % (args[0] if args else "~"))
                else:
                    _cwd = target
            elif cmd == "ls":
                long = "-l" in args
                paths = [a for a in args if not a.startswith("-")] or ["."]
                for pth in paths:
                    full = _resolve(pth)
                    if os.path.isdir(full):
                        names = sorted(os.listdir(full), key=lambda x: (not os.path.isdir(os.path.join(full, x)), x.lower()))
                        for nm in names:
                            if nm == "__pycache__":
                                continue
                            isd = os.path.isdir(os.path.join(full, nm))
                            if long:
                                size = "-" if isd else str(os.path.getsize(os.path.join(full, nm)))
                                out.write("%8s  %s%s\n" % (size, nm, "/" if isd else ""))
                            else:
                                out.write(nm + ("/" if isd else "") + "\n")
                    elif os.path.exists(full):
                        out.write(os.path.basename(full) + "\n")
                    else:
                        out.write("нет такого пути: %s\n" % pth)
            elif cmd == "cat":
                for a in args:
                    full = _resolve(a)
                    if os.path.isfile(full):
                        with open(full, encoding="utf-8", errors="replace") as f:
                            data = f.read(200000)
                        out.write(data + ("" if data.endswith("\n") else "\n"))
                    else:
                        out.write("нет такого файла: %s\n" % a)
            elif cmd == "mkdir":
                for a in [x for x in args if not x.startswith("-")]:
                    os.makedirs(_resolve(a), exist_ok=True)
            elif cmd == "touch":
                for a in args:
                    full = _resolve(a)
                    os.makedirs(os.path.dirname(full), exist_ok=True)
                    open(full, "a").close()
            elif cmd == "rm":
                rec = any(x in ("-r", "-rf", "-fr", "-R") for x in args)
                for a in [x for x in args if not x.startswith("-")]:
                    full = _resolve(a)
                    if full == ROOT:
                        out.write("корень проекта удалять нельзя\n")
                    elif os.path.isdir(full):
                        if rec:
                            shutil.rmtree(full)
                        else:
                            out.write("%s - папка, нужен rm -r\n" % a)
                    elif os.path.exists(full):
                        os.remove(full)
                    else:
                        out.write("нет такого пути: %s\n" % a)
            elif cmd in ("mv", "cp"):
                srcs = [x for x in args if not x.startswith("-")]
                if len(srcs) != 2:
                    out.write("использование: %s <откуда> <куда>\n" % cmd)
                else:
                    a, b = _resolve(srcs[0]), _resolve(srcs[1])
                    if cmd == "mv":
                        shutil.move(a, b)
                    elif os.path.isdir(a):
                        shutil.copytree(a, b)
                    else:
                        shutil.copy2(a, b)
            elif cmd == "echo":
                if ">" in args or ">>" in args:
                    op = ">>" if ">>" in args else ">"
                    i = args.index(op)
                    text = " ".join(args[:i])
                    if i + 1 < len(args):
                        with open(_resolve(args[i + 1]), "a" if op == ">>" else "w", encoding="utf-8") as f:
                            f.write(text + "\n")
                    else:
                        out.write("не указан файл после %s\n" % op)
                else:
                    out.write(" ".join(args) + "\n")
            elif cmd in ("clear", "cls"):
                clear = True
            elif cmd in ("python", "python3"):
                if not args:
                    out.write("Для интерактивного режима введи python в пустой строке терминала.\n")
                else:
                    full = _resolve(args[0])
                    if os.path.isfile(full):
                        out.write(_run_script_capture(full, args[1:]))
                    else:
                        out.write("нет такого файла: %s\n" % args[0])
            elif cmd in ("pip", "pip3"):
                sub = args[0] if args else ""
                names = [a for a in args[1:] if not a.startswith("-")]
                if sub == "install":
                    if "-r" in args:
                        i = args.index("-r")
                        req = _resolve(args[i + 1]) if i + 1 < len(args) else ""
                        names = []
                        if os.path.isfile(req):
                            for ln in open(req, encoding="utf-8"):
                                ln = ln.split("#")[0].strip()
                                if ln:
                                    names.append(ln)
                    out.write(pip_install(" ".join(names)) + "\n" if names else "укажи имя пакета: pip install requests\n")
                elif sub == "uninstall":
                    out.write(_pip_uninstall(names))
                elif sub in ("list", "freeze"):
                    out.write(_pip_list())
                else:
                    out.write("использование: pip install <пакет> | pip uninstall <пакет> | pip list\n")
            elif cmd == "git":
                out.write(_git_cmd(args))
            else:
                out.write("команда не найдена: %s (введи help)\n" % cmd)
        except PermissionError as e:
            out.write("запрещено: %s\n" % e)
        except Exception as e:
            out.write("ошибка: %s: %s\n" % (type(e).__name__, e))
    return json.dumps({"out": out.getvalue(), "cwd": _rel_cwd(), "clear": clear})
