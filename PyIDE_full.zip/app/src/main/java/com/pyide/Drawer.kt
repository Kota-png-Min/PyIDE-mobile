package com.pyide

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Левая панель: Project / Structure / Git. */
@Composable
fun AppDrawer(ide: Ide, onClose: () -> Unit, onDialog: (Dlg) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    ModalDrawerSheet(
        drawerContainerColor = Ds.bg,
        drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp),
        windowInsets = WindowInsets(0, 0, 0, 0),
        modifier = Modifier.width(332.dp)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(top = 16.dp)
        ) {
            Text("PyIDE", style = Ds.title1, modifier = Modifier.padding(horizontal = 20.dp))
            Text(
                ide.root.name, style = Ds.caption,
                modifier = Modifier.padding(start = 20.dp, top = 2.dp, bottom = 14.dp)
            )
            Row(
                Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Project", "Structure", "Git").forEachIndexed { i, name ->
                    DsChip(name, selected = tab == i, onClick = { tab = i })
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(top = 10.dp)) {
                when (tab) {
                    0 -> ProjectTab(ide, onClose, onDialog)
                    1 -> StructureTab(ide, onClose)
                    else -> GitTab(ide, onClose, onDialog)
                }
            }
        }
    }
}

// ======================= Project =======================

private data class TreeItem(val path: String, val name: String, val depth: Int, val isDir: Boolean)

private fun buildRows(files: List<File>, root: File, expanded: Map<String, Boolean>): List<TreeItem> {
    class Node(val path: String) {
        val dirs = sortedMapOf<String, Node>()
        val files = mutableListOf<String>()
    }

    val top = Node("")
    val rels = files.map { it.relativeTo(root).path.replace(File.separatorChar, '/') }.sorted()
    for (rel in rels) {
        val parts = rel.split("/")
        var cur = top
        for (i in 0 until parts.size - 1) {
            val p = parts.subList(0, i + 1).joinToString("/")
            cur = cur.dirs.getOrPut(parts[i]) { Node(p) }
        }
        cur.files.add(parts.last())
    }
    val out = mutableListOf<TreeItem>()
    fun walk(n: Node, depth: Int) {
        for ((name, d) in n.dirs) {
            out.add(TreeItem(d.path, name, depth, true))
            if (expanded[d.path] != false) walk(d, depth + 1)
        }
        for (f in n.files.sorted()) {
            out.add(TreeItem(if (n.path.isEmpty()) f else n.path + "/" + f, f, depth, false))
        }
    }
    walk(top, 0)
    return out
}

@Composable
private fun ProjectTab(ide: Ide, onClose: () -> Unit, onDialog: (Dlg) -> Unit) {
    val expanded = remember { mutableStateMapOf<String, Boolean>() }
    val rows = buildRows(ide.files, ide.root, expanded)
    val activePath = ide.tabs.getOrNull(ide.active)?.relativeTo(ide.root)?.path?.replace(File.separatorChar, '/')

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Files", style = Ds.headline, modifier = Modifier.weight(1f))
            DsIconButton(Ic.Search, onClick = { onDialog(Dlg.Search) }, size = 40.dp)
            DsIconButton(Ic.Plus, onClick = { onDialog(Dlg.NewFile("")) }, filled = true, size = 40.dp)
        }
        if (rows.isEmpty()) {
            Text(
                "Проект пуст. Нажми плюс, чтобы создать файл.",
                style = Ds.subhead, color = Ds.gray, modifier = Modifier.padding(20.dp)
            )
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(rows, key = { (if (it.isDir) "d:" else "f:") + it.path }) { row ->
                TreeRow(
                    row = row,
                    isOpen = row.isDir && expanded[row.path] != false,
                    isActive = !row.isDir && row.path == activePath,
                    onTap = {
                        if (row.isDir) expanded[row.path] = expanded[row.path] == false
                        else {
                            ide.open(File(ide.root, row.path))
                            onClose()
                        }
                    },
                    onDialog = onDialog,
                    ide = ide
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TreeRow(
    row: TreeItem,
    isOpen: Boolean,
    isActive: Boolean,
    onTap: () -> Unit,
    onDialog: (Dlg) -> Unit,
    ide: Ide,
) {
    var menu by remember { mutableStateOf(false) }
    val target = File(ide.root, row.path)
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .padding(horizontal = 8.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(if (isActive) Ds.surface else Color.Transparent)
                .combinedClickable(onClick = onTap, onLongClick = { menu = true })
                .padding(start = (8 + row.depth * 18).dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (row.isDir) {
                DsIcon(if (isOpen) Ic.ChevronDown else Ic.ChevronRight, Ds.gray, 16.dp)
                DsIcon(if (isOpen) Ic.FolderOpen else Ic.Folder, Ds.orange, 22.dp)
            } else {
                Box(Modifier.size(16.dp))
                DsIcon(Ic.File, if (row.name.endsWith(".py")) Ds.orange else Ds.gray, 22.dp)
            }
            Text(
                row.name,
                style = Ds.body.copy(fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal),
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        DropdownMenu(
            expanded = menu,
            onDismissRequest = { menu = false },
            modifier = Modifier.background(Ds.surface)
        ) {
            if (row.isDir) {
                DropdownMenuItem(
                    text = { Text("Создать файл") },
                    leadingIcon = { DsIcon(Ic.Plus, Ds.orange, 20.dp) },
                    onClick = { menu = false; onDialog(Dlg.NewFile(row.path + "/")) }
                )
                DropdownMenuItem(
                    text = { Text("Удалить папку", color = Ds.red) },
                    leadingIcon = { DsIcon(Ic.Trash, Ds.red, 20.dp) },
                    onClick = {
                        menu = false
                        onDialog(Dlg.Confirm("Удалить папку", "Папка ${row.name} и всё внутри будет удалено.") {
                            ide.files
                                .filter { it.path.startsWith(target.path + File.separator) }
                                .forEach { ide.delete(it) }
                            target.deleteRecursively()
                            ide.refresh()
                        })
                    }
                )
            } else {
                DropdownMenuItem(
                    text = { Text("Переименовать") },
                    leadingIcon = { DsIcon(Ic.Pencil, Ds.orange, 20.dp) },
                    onClick = { menu = false; onDialog(Dlg.Rename(target, row.path)) }
                )
                DropdownMenuItem(
                    text = { Text("Удалить", color = Ds.red) },
                    leadingIcon = { DsIcon(Ic.Trash, Ds.red, 20.dp) },
                    onClick = {
                        menu = false
                        onDialog(Dlg.Confirm("Удалить файл", "Файл ${row.name} будет удалён.") {
                            ide.delete(target)
                        })
                    }
                )
            }
        }
    }
}

// ======================= Structure =======================

private data class Symbol(val kind: String, val name: String, val line: Int, val depth: Int)

private val SYMBOL_RE = Regex("""^(\s*)(?:async\s+)?(def|class)\s+([A-Za-z_]\w*)""")

private fun parseSymbols(text: String): List<Symbol> {
    val out = mutableListOf<Symbol>()
    text.split("\n").forEachIndexed { i, line ->
        val m = SYMBOL_RE.find(line)
        if (m != null) {
            out.add(Symbol(m.groupValues[2], m.groupValues[3], i + 1, m.groupValues[1].length / 4))
        }
    }
    return out
}

@Composable
private fun StructureTab(ide: Ide, onClose: () -> Unit) {
    val f = ide.tabs.getOrNull(ide.active)
    val text = f?.let { ide.texts[it.path]?.text }
    if (f == null || text == null) {
        Text("Открой файл, чтобы увидеть его структуру.", style = Ds.subhead, color = Ds.gray, modifier = Modifier.padding(20.dp))
        return
    }
    val symbols = parseSymbols(text)
    if (symbols.isEmpty()) {
        Text("В ${f.name} нет функций и классов.", style = Ds.subhead, color = Ds.gray, modifier = Modifier.padding(20.dp))
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(symbols) { s ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .padding(horizontal = 8.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { ide.gotoLine(f.path, s.line); onClose() }
                    .padding(start = (8 + s.depth * 18).dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val isClass = s.kind == "class"
                val color = if (isClass) Color(0xFFFFC66D) else Ds.orange
                Box(
                    Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (isClass) "C" else "f", color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    s.name, style = Ds.body.copy(fontFamily = FontFamily.Monospace, fontSize = 15.sp),
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Text("${s.line}", style = Ds.caption)
            }
        }
    }
}

// ======================= Git =======================

@Composable
private fun GitTab(ide: Ide, onClose: () -> Unit, onDialog: (Dlg) -> Unit) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun load() {
        scope.launch {
            busy = true
            text = withContext(Dispatchers.IO) {
                try { Backend.git("status", ".") } catch (e: Exception) { "Ошибка: $e" }
            }
            busy = false
        }
    }
    LaunchedEffect(Unit) { load() }

    val lines = text.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    val branch = lines.firstOrNull { it.startsWith("ветка:") }?.removePrefix("ветка:")?.trim()
    val changes = lines.mapNotNull { l ->
        when {
            l.startsWith("изменён:") -> "M" to l.removePrefix("изменён:").trim()
            l.startsWith("новый:") -> "U" to l.removePrefix("новый:").trim()
            l.startsWith("в индексе") -> "A" to l.substringAfter(":").trim()
            else -> null
        }
    }
    val recognized = listOf("ветка:", "изменён:", "новый:", "в индексе", "нет изменений")
    val problem = lines.filter { l -> recognized.none { l.startsWith(it) } }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (branch != null) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Ds.surface)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DsIcon(Ic.Branch, Ds.orange, 16.dp)
                    Text(branch, style = Ds.subhead)
                }
            }
            Box(Modifier.weight(1f))
            DsIconButton(Ic.Refresh, onClick = { load() }, enabled = !busy, size = 40.dp)
            DsButton("Tools", onClick = { onDialog(Dlg.Git) }, kind = DsBtn.Outlined)
        }
        if (problem.isNotEmpty()) {
            Text(
                problem.joinToString("\n") + "\n\nОткрой Tools и нажми Init, если репозитория ещё нет.",
                style = Ds.subhead, color = Ds.gray, modifier = Modifier.padding(20.dp)
            )
        } else if (changes.isEmpty()) {
            Text("Изменений нет.", style = Ds.subhead, color = Ds.gray, modifier = Modifier.padding(20.dp))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(changes) { (kind, path) ->
                val color = when (kind) {
                    "M" -> Ds.orange
                    "U" -> Ds.green
                    else -> Color(0xFF6897BB)
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .padding(horizontal = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable {
                            val file = File(ide.root, path)
                            if (file.exists()) { ide.open(file); onClose() }
                        }
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(color.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(kind, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(path, style = Ds.body.copy(fontSize = 15.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
