package com.pyide

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Дизайн-система: тёмный фон, графитовые карточки, оранжевый акцент, скруглённые пилюли. */
object Ds {
    val bg = Color(0xFF0B0B0D)
    val surface = Color(0xFF26262B)
    val field = Color(0xFF0D0D0F)
    val editor = Color(0xFF101012)
    val line = Color(0xFF3A3A40)
    val orange = Color(0xFFFF7512)
    val gray = Color(0xFF878787)
    val red = Color(0xFFFF5A5A)
    val green = Color(0xFF6A8759)
    val white = Color.White

    val largeTitle = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
    val title1 = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
    val title2 = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
    val headline = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
    val body = TextStyle(fontSize = 16.sp, color = Color.White)
    val subhead = TextStyle(fontSize = 14.sp, color = Color.White)
    val caption = TextStyle(fontSize = 12.sp, color = Color(0xFF878787))
    val mono = TextStyle(
        fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp,
        color = Color(0xFFD0D0D4)
    )
}

@Composable
fun DsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Ds.orange, onPrimary = Color.White,
            background = Ds.bg, onBackground = Color.White,
            surface = Ds.surface, onSurface = Color.White,
            surfaceVariant = Ds.surface, onSurfaceVariant = Ds.gray,
            outline = Ds.orange, error = Ds.red
        ),
        content = content
    )
}

/** Карточка с оранжевым контуром (как в дизайн-системе). */
fun Modifier.outlinedCard(radius: Dp = 20.dp, color: Color = Ds.orange): Modifier {
    val shape = RoundedCornerShape(radius)
    return this.clip(shape).background(Ds.surface).border(1.5.dp, color, shape)
}

/** Круглая кнопка с нарисованной иконкой. Минимальная зона нажатия 44 dp. */
@Composable
fun DsIconButton(
    ic: Ic,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = false,
    outlined: Boolean = false,
    tint: Color? = null,
    size: Dp = 44.dp,
) {
    val bg = if (filled && enabled) Ds.orange else Ds.surface
    val fg = tint ?: when {
        !enabled -> Color(0xFF55555A)
        filled -> Color.White
        outlined -> Ds.orange
        else -> Color.White
    }
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(bg)
            .then(if (outlined && enabled) Modifier.border(1.5.dp, Ds.orange, CircleShape) else Modifier)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { DsIcon(ic, fg, 22.dp) }
}

/** Пилюля-метка: выбранная заливается оранжевым, остальные графитовые. */
@Composable
fun DsChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .heightIn(min = 40.dp)
            .clip(shape)
            .background(if (selected) Ds.orange else Ds.surface)
            .then(if (!selected) Modifier.border(1.dp, Ds.line, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        leading?.invoke()
        Text(
            label,
            style = Ds.subhead.copy(fontWeight = FontWeight.Medium),
            color = if (selected) Color.White else Color(0xFFD0D0D4),
            maxLines = 1
        )
        trailing?.invoke()
    }
}

enum class DsBtn { Filled, Outlined, Gray }

/** Большая кнопка-пилюля ("отправить" и т.п.). */
@Composable
fun DsButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: DsBtn = DsBtn.Filled,
    enabled: Boolean = true,
    icon: Ic? = null,
) {
    val shape = RoundedCornerShape(50)
    val bg = when {
        !enabled -> Ds.surface
        kind == DsBtn.Filled -> Ds.orange
        kind == DsBtn.Gray -> Color(0xFF3A3A40)
        else -> Color.Transparent
    }
    val fg = when {
        !enabled -> Color(0xFF55555A)
        kind == DsBtn.Outlined -> Ds.orange
        else -> Color.White
    }
    Row(
        modifier
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(bg)
            .then(if (kind == DsBtn.Outlined && enabled) Modifier.border(1.5.dp, Ds.orange, shape) else Modifier)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
    ) {
        if (icon != null) DsIcon(icon, fg, 18.dp)
        Text(text, style = Ds.subhead.copy(fontWeight = FontWeight.SemiBold), color = fg, maxLines = 1)
    }
}

/** Поле ввода: тёмная плашка на графитовом фоне, оранжевый курсор. */
@Composable
fun DsField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    mono: Boolean = true,
    onSend: (() -> Unit)? = null,
    onFocus: ((Boolean) -> Unit)? = null,
) {
    val family = if (mono) FontFamily.Monospace else FontFamily.Default
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 15.sp, fontFamily = family),
        cursorBrush = SolidColor(Ds.orange),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.None,
            autoCorrectEnabled = false,
            imeAction = if (onSend != null) ImeAction.Send else ImeAction.Default
        ),
        keyboardActions = KeyboardActions(onSend = { onSend?.invoke() }),
        modifier = modifier
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Ds.field)
            .onFocusChanged { onFocus?.invoke(it.isFocused) }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        decorationBox = { inner ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) {
                    Text(hint, color = Ds.gray, fontSize = 15.sp, fontFamily = family, maxLines = 1)
                }
                inner()
            }
        }
    )
}
