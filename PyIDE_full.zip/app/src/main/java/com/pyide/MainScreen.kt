package com.pyide

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Какой диалог сейчас открыт. */
sealed interface Dlg {
    data object Pip : Dlg
    data object Git : Dlg
    data object Search : Dlg
    data object Settings : Dlg
    data class NewFile(val prefix: String) : Dlg
    data class Rename(val file: File, val rel: String) : Dlg
    data class Confirm(val title: String, val text: String, val action: () -> Unit) : Dlg
}

@Composable
private fun MenuRow(text: String, ic: Ic, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(text) },
        leadingIcon = { DsIcon(ic, Ds.orange, 20.dp) },
        onClick = onClick
    )
}

@Composable
fun MainScreen(ide: Ide) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var dialog by remember { mutableStateOf<Dlg?>(null) }
    var menu by remember { mutableStateOf(false) }
    var bigPanel by remember { mutableStateOf(false) }

    // импорт и экспорт через системный выбор файлов
    val ctx = LocalContext.current
    var exportTarget by remember { mutableStateOf<File?>(null) }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val n = importUris(ctx, ide, uris)
        ide.status = if (n > 0) "Импортировано файлов: $n" else "Ничего не импортировано"
    }
    val exportFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val tf = exportTarget
        if (uri != null && tf != null) {
            ide.status = try {
                val text = ide.texts[tf.path]?.text ?: tf.readText()
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                "Файл экспортирован"
            } catch (e: Exception) { "Ошибка экспорта: ${e.message}" }
        }
    }
    val exportZipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            ide.status = try {
                exportZip(ctx, ide, uri)
                "Проект экспортирован"
            } catch (e: Exception) { "Ошибка экспорта: ${e.message}" }
        }
    }

    // опрос состояния запущенной программы и отладчика
    LaunchedEffect(Unit) {
        while (true) {
            if (ide.polling) {
                try { ide.poll() } catch (_: Exception) { ide.polling = false }
            }
            delay(120)
        }
    }

    val f = ide.tabs.getOrNull(ide.active)
    val running = ide.runState.running
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    LaunchedEffect(imeOpen) { if (!imeOpen) ide.panelFocused = false }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            AppDrawer(
                ide = ide,
                onClose = { scope.launch { drawer.close() } },
                onDialog = { dialog = it }
            )
        }
    ) {
        Scaffold(
            containerColor = Ds.bg,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                // ---------- верхняя панель ----------
                val pause = ide.runState.pause
                val subtitle = when {
                    pause != null -> "Paused, line ${pause.line}"
                    running -> "Running"
                    else -> ide.root.name
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Ds.bg)
                        .statusBarsPadding()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DsIconButton(Ic.Menu, onClick = { scope.launch { drawer.open() } })
                    Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                        Text(
                            f?.name ?: "PyIDE", style = Ds.headline,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(subtitle, style = Ds.caption, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DsIconButton(
                        Ic.Play, filled = true, enabled = !running && f != null,
                        onClick = { scope.launch { ide.launch(false) } }
                    )
                    DsIconButton(
                        Ic.Debug, outlined = true, enabled = !running && f != null,
                        onClick = { scope.launch { ide.launch(true) } }
                    )
                    DsIconButton(
                        Ic.Stop, enabled = running, tint = if (running) Ds.red else null,
                        onClick = { scope.launch { ide.stop() } }
                    )
                    Box {
                        DsIconButton(Ic.More, onClick = { menu = true })
                        DropdownMenu(
                            expanded = menu,
                            onDismissRequest = { menu = false },
                            modifier = Modifier.background(Ds.surface)
                        ) {
                            MenuRow("Найти / заменить", Ic.Search) { menu = false; ide.findOpen = !ide.findOpen }
                            MenuRow("Форматировать код", Ic.Check) {
                                menu = false
                                f?.let { scope.launch { ide.format(it) } }
                            }
                            MenuRow("К определению", Ic.ChevronRight) {
                                menu = false
                                f?.let { scope.launch { ide.gotoDef(it) } }
                            }
                            MenuRow("Закомментировать строки", Ic.Pencil) {
                                menu = false
                                f?.let { ide.comment(it) }
                            }
                            MenuRow("Поиск по проекту", Ic.Search) { menu = false; dialog = Dlg.Search }
                            MenuRow("Пакеты (pip)", Ic.Plus) { menu = false; dialog = Dlg.Pip }
                            MenuRow("Git", Ic.Branch) { menu = false; dialog = Dlg.Git }
                            MenuRow("Импорт файлов", Ic.Plus) { menu = false; importLauncher.launch(arrayOf("*/*")) }
                            MenuRow("Экспорт файла", Ic.Send) {
                                menu = false
                                if (f != null) { exportTarget = f; exportFileLauncher.launch(f.name) }
                            }
                            MenuRow("Экспорт проекта (zip)", Ic.Folder) { menu = false; exportZipLauncher.launch("project.zip") }
                            MenuRow("Настройки", Ic.Structure) { menu = false; dialog = Dlg.Settings }
                        }
                    }
                }
            }
        ) { pad ->
            Column(
                Modifier
                    .padding(pad)
                    .fillMaxSize()
                    .navigationBarsPadding()
                    .imePadding()
            ) {
                // ---------- вкладки открытых файлов ----------
                if (ide.tabs.isNotEmpty()) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(ide.tabs, key = { _, file -> file.path }) { i, file ->
                            DsChip(
                                label = file.name,
                                selected = i == ide.active,
                                onClick = { ide.active = i },
                                trailing = {
                                    Box(
                                        Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .clickable { ide.close(i) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        DsIcon(Ic.Close, if (i == ide.active) Color.White else Ds.gray, 14.dp)
                                    }
                                }
                            )
                        }
                    }
                }

                if (f != null && ide.findOpen) FindBar(ide, f)

                // ---------- редактор + окно подсказок ----------
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (f != null) {
                        key(f.path) { EditorPane(ide, f, Modifier.fillMaxSize()) }
                        CompletionPopup(ide, f, Modifier.align(Alignment.BottomStart).padding(10.dp))
                    } else {
                        Column(
                            Modifier
                                .align(Alignment.Center)
                                .padding(24.dp)
                                .outlinedCard(24.dp)
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("PyIDE", style = Ds.title1)
                            Text("Открой файл из проекта", style = Ds.subhead, color = Ds.gray)
                            DsButton(
                                "Open project", icon = Ic.Folder,
                                onClick = { scope.launch { drawer.open() } }
                            )
                        }
                    }
                }

                if (f != null) {
                    QuickSymbolBar(ide, f)
                    StatusBar(ide, f)
                }

                // над клавиатурой остаётся только панель символов; шторка прячется,
                // пока пользователь не печатает в её полях ввода
                if (!(imeOpen && !ide.panelFocused)) {
                    BottomPanel(ide, bigPanel) { bigPanel = it }
                }
            }
        }
    }

    // ---------- диалоги ----------
    when (val d = dialog) {
        null -> {}
        Dlg.Pip -> PipDialog { dialog = null }
        Dlg.Git -> GitDialog(ide) { dialog = null }
        Dlg.Settings -> SettingsDialog(ide) { dialog = null }
        Dlg.Search -> SearchDialog(ide) {
            dialog = null
            scope.launch { drawer.close() }
        }
        is Dlg.NewFile -> NameDialog(
            title = "Новый файл", initial = d.prefix, hint = "dir/script.py",
            onDismiss = { dialog = null },
            onOk = { name ->
                ide.create(name)
                dialog = null
                scope.launch { drawer.close() }
            }
        )
        is Dlg.Rename -> NameDialog(
            title = "Переименовать", initial = d.rel, hint = "dir/script.py",
            onDismiss = { dialog = null },
            onOk = { name ->
                ide.rename(d.file, name)
                dialog = null
            }
        )
        is Dlg.Confirm -> ConfirmDialog(
            title = d.title, text = d.text,
            onDismiss = { dialog = null },
            onYes = {
                d.action()
                dialog = null
            }
        )
    }
}

// ======================= Импорт и экспорт =======================

private fun displayName(ctx: Context, uri: Uri): String {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) return c.getString(i)
    }
    return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
}

/** Копирует выбранные файлы в корень проекта. Существующие не перезаписываются: добавляется _1, _2. */
private fun importUris(ctx: Context, ide: Ide, uris: List<Uri>): Int {
    var n = 0
    for (uri in uris) {
        try {
            val name = displayName(ctx, uri).substringAfterLast('/').ifBlank { "file" }
            val base = name.substringBeforeLast('.', name)
            val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
            var dest = File(ide.root, name)
            var k = 1
            while (dest.exists()) {
                dest = File(ide.root, base + "_" + k + ext)
                k++
            }
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { out -> input.copyTo(out) }
            }
            n++
        } catch (_: Exception) {
        }
    }
    ide.refresh()
    return n
}

private fun exportZip(ctx: Context, ide: Ide, uri: Uri) {
    ctx.contentResolver.openOutputStream(uri)?.use { os ->
        ZipOutputStream(os).use { zip ->
            ide.root.walkTopDown()
                .onEnter { it.name != "__pycache__" }
                .filter { it.isFile }
                .forEach { f ->
                    zip.putNextEntry(ZipEntry(f.relativeTo(ide.root).path.replace(File.separatorChar, '/')))
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
        }
    }
}
