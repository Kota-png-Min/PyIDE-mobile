package com.pyide

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Настройки интерфейса. Хранятся в SharedPreferences, читаются при старте. */
object Prefs {
    var fontSize by mutableFloatStateOf(14f)
    var hints by mutableStateOf(true)
    private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("pyide", Context.MODE_PRIVATE)
        sp = p
        fontSize = p.getFloat("font", 14f)
        hints = p.getBoolean("hints", true)
    }

    fun save() {
        sp?.edit()?.putFloat("font", fontSize)?.putBoolean("hints", hints)?.apply()
    }
}
